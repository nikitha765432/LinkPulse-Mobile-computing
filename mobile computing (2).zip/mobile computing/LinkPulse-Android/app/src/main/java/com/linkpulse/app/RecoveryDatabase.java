package com.linkpulse.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * LinkPulse - RecoveryDatabase
 * Section 18: Local SQLite persistence for recovery audit history.
 */
public class RecoveryDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "linkpulse_recovery.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_RECOVERY = "recovery_events";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_TIMESTAMP = "timestamp";
    public static final String COLUMN_PREV_NETWORK = "previous_network";
    public static final String COLUMN_NEW_NETWORK = "new_network";
    public static final String COLUMN_REASON = "reason";
    public static final String COLUMN_FAILURE_PROB = "failure_probability";
    public static final String COLUMN_OLD_SCORE = "old_network_score";
    public static final String COLUMN_NEW_SCORE = "new_network_score";
    public static final String COLUMN_RECOVERY_TIME = "recovery_time";
    public static final String COLUMN_RESULT = "result";

    public RecoveryDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_RECOVERY + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_TIMESTAMP + " TEXT, " +
                COLUMN_PREV_NETWORK + " TEXT, " +
                COLUMN_NEW_NETWORK + " TEXT, " +
                COLUMN_REASON + " TEXT, " +
                COLUMN_FAILURE_PROB + " INTEGER, " +
                COLUMN_OLD_SCORE + " INTEGER, " +
                COLUMN_NEW_SCORE + " INTEGER, " +
                COLUMN_RECOVERY_TIME + " TEXT, " +
                COLUMN_RESULT + " TEXT" +
                ")";
        db.execSQL(createTable);

        // Prepopulate with demonstration records matching Section 18
        insertInitialSeedRecords(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RECOVERY);
        onCreate(db);
    }

    private void insertInitialSeedRecords(SQLiteDatabase db) {
        insertRowDirect(db, "23-11-2026 12:35", "Wi-Fi", "5G", "High packet loss (86% fail prob)", 86, 38, 89, "1.8s", "SUCCESS");
        insertRowDirect(db, "23-11-2026 12:20", "5G", "Wi-Fi", "Reverse Recovery: 5G congested, Wi-Fi superior", 74, 45, 84, "1.9s", "SUCCESS");
        insertRowDirect(db, "23-11-2026 12:05", "4G", "None", "Improvement below +15 pt threshold", 52, 58, 64, "-", "NO_SWITCH");
    }

    private void insertRowDirect(SQLiteDatabase db, String time, String prev, String next, String reason, int prob, int oldSc, int newSc, String recTime, String res) {
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_TIMESTAMP, time);
        cv.put(COLUMN_PREV_NETWORK, prev);
        cv.put(COLUMN_NEW_NETWORK, next);
        cv.put(COLUMN_REASON, reason);
        cv.put(COLUMN_FAILURE_PROB, prob);
        cv.put(COLUMN_OLD_SCORE, oldSc);
        cv.put(COLUMN_NEW_SCORE, newSc);
        cv.put(COLUMN_RECOVERY_TIME, recTime);
        cv.put(COLUMN_RESULT, res);
        db.insert(TABLE_RECOVERY, null, cv);
    }

    public synchronized long insertEvent(RecoveryEvent event) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_TIMESTAMP, event.getTimestamp());
        cv.put(COLUMN_PREV_NETWORK, event.getPreviousNetwork());
        cv.put(COLUMN_NEW_NETWORK, event.getNewNetwork());
        cv.put(COLUMN_REASON, event.getReason());
        cv.put(COLUMN_FAILURE_PROB, event.getFailureProbability());
        cv.put(COLUMN_OLD_SCORE, event.getOldNetworkScore());
        cv.put(COLUMN_NEW_SCORE, event.getNewNetworkScore());
        cv.put(COLUMN_RECOVERY_TIME, event.getRecoveryTime());
        cv.put(COLUMN_RESULT, event.getResult());
        return db.insert(TABLE_RECOVERY, null, cv);
    }

    public synchronized List<RecoveryEvent> getAllEvents() {
        List<RecoveryEvent> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_RECOVERY, null, null, null, null, null, COLUMN_ID + " DESC", "40");

        if (cursor != null && cursor.moveToFirst()) {
            do {
                RecoveryEvent e = new RecoveryEvent();
                e.setId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                e.setTimestamp(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TIMESTAMP)));
                e.setPreviousNetwork(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PREV_NETWORK)));
                e.setNewNetwork(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NEW_NETWORK)));
                e.setReason(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_REASON)));
                e.setFailureProbability(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_FAILURE_PROB)));
                e.setOldNetworkScore(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_OLD_SCORE)));
                e.setNewNetworkScore(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_NEW_SCORE)));
                e.setRecoveryTime(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_RECOVERY_TIME)));
                e.setResult(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_RESULT)));
                list.add(e);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return list;
    }

    public synchronized void clearHistory() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_RECOVERY, null, null);
    }
}
