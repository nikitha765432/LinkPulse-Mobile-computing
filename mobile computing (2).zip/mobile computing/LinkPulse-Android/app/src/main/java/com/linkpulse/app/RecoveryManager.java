package com.linkpulse.app;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * LinkPulse - RecoveryManager
 * Section 8: Autonomous 8-State Smart Recovery Lifecycle Manager.
 *
 * State flow:
 *   MONITORING -> DEGRADING -> FAILURE_PREDICTED -> RECOVERY_SEARCH
 *   -> NETWORK_SELECTED -> REQUESTING -> VERIFYING -> RECOVERED (or RECOVERY_FAILED)
 */
public class RecoveryManager {
    private static final String TAG = "LinkPulse-Recovery";
    public static final long RECOVERY_TIMEOUT_MS = 10000; // 10s recovery timeout

    public enum RecoveryState {
        MONITORING,
        DEGRADING,
        FAILURE_PREDICTED,
        RECOVERY_SEARCH,
        NETWORK_SELECTED,
        SWITCHING,
        VERIFYING,
        RECOVERED,
        RECOVERY_FAILED
    }

    public interface OnRecoveryListener {
        void onRecoveryStateChanged(RecoveryState state, String statusMessage);
        void onCandidatesEvaluated(List<NetworkMetrics> candidates, NetworkMetrics selected);
        void onRecoveryCompleted(RecoveryEvent event);
    }

    private final Context context;
    private final ConnectivityManager connectivityManager;
    private final RecoveryDatabase database;
    private final Handler mainHandler;

    private RecoveryState currentState = RecoveryState.MONITORING;
    private long lastRecoveryTimestamp = 0;
    private OnRecoveryListener listener;

    private ConnectivityManager.NetworkCallback pendingSwitchCallback;
    private Runnable timeoutRunnable;

    public RecoveryManager(Context context, RecoveryDatabase database) {
        this.context = context.getApplicationContext();
        this.database = database;
        this.connectivityManager = (ConnectivityManager) this.context.getSystemService(Context.CONNECTIVITY_SERVICE);
        this.mainHandler = new Handler(Looper.getMainLooper());
    }

    public void setListener(OnRecoveryListener listener) {
        this.listener = listener;
    }

    public RecoveryState getCurrentState() {
        return currentState;
    }

    /**
     * Evaluates live telemetry metrics and triggers recovery if failure risk is high
     */
    public void processMetrics(NetworkMetrics metrics) {
        FailurePredictionManager.PredictionResult pred = FailurePredictionManager.predict(metrics);

        if (pred.recoveryRequired) {
            Log.d(TAG, "[LinkPulse] Failure probability: " + pred.failureProbability);
            Log.d(TAG, "[LinkPulse] High risk detected");
            if (currentState == RecoveryState.MONITORING || currentState == RecoveryState.DEGRADING) {
                transitionState(RecoveryState.FAILURE_PREDICTED, "High failure risk predicted (" + pred.failureProbabilityPercent + "%). Triggering recovery.");
                triggerRecovery(metrics, pred);
            }
        } else if (pred.status.equals("WARNING")) {
            if (currentState == RecoveryState.MONITORING) {
                transitionState(RecoveryState.DEGRADING, "Network degradation detected. Latency variance is elevated.");
            }
        } else {
            if (currentState != RecoveryState.SWITCHING && currentState != RecoveryState.VERIFYING) {
                transitionState(RecoveryState.MONITORING, "Connection is stable and nominal.");
            }
        }
    }

    /**
     * Executes the recovery pipeline across candidate networks
     */
    public void triggerRecovery(NetworkMetrics currentMetrics, FailurePredictionManager.PredictionResult pred) {
        Log.d(TAG, "[LinkPulse] Smart Recovery triggered");
        transitionState(RecoveryState.RECOVERY_SEARCH, "Searching for available alternative networks...");

        // Discover candidates (Wi-Fi, 4G, 5G)
        List<NetworkMetrics> candidates = discoverAlternativeCandidates(currentMetrics);

        mainHandler.postDelayed(() -> {
            // Evaluate candidates using weighted Network Score
            NetworkSelector.SelectionDecision decision = NetworkSelector.evaluateCandidates(
                    currentMetrics, candidates, lastRecoveryTimestamp
            );

            if (listener != null) {
                listener.onCandidatesEvaluated(candidates, decision.bestCandidate);
            }

            if (!decision.switchRecommended || decision.bestCandidate == null) {
                Log.w(TAG, "[LinkPulse] " + decision.reason);
                handleRecoveryFailure(currentMetrics.getNetworkType(), "No suitable alternative (" + decision.reason + ")",
                        decision.currentScore, decision.candidateScore, pred.failureProbabilityPercent);
                return;
            }

            // Network Selected
            NetworkMetrics target = decision.bestCandidate;
            Log.d(TAG, "[LinkPulse] Best candidate selected: " + target.getNetworkType() + " (Score " + decision.candidateScore + ")");
            transitionState(RecoveryState.NETWORK_SELECTED, "Selected: " + target.getNetworkType() + " (Score " + decision.candidateScore + " vs Current " + decision.currentScore + ")");

            // Request Network via Android ConnectivityManager
            mainHandler.postDelayed(() -> {
                executeNetworkSwitch(currentMetrics, target, decision, pred.failureProbabilityPercent);
            }, 800);

        }, 800);
    }

    /**
     * Requests the desired transport through Android-supported NetworkRequest API
     */
    private void executeNetworkSwitch(NetworkMetrics fromNet, NetworkMetrics toNet,
                                     NetworkSelector.SelectionDecision decision, int failureProb) {
        transitionState(RecoveryState.SWITCHING, "Requesting network route for " + toNet.getNetworkType() + " via Android API...");
        Log.d(TAG, "[LinkPulse] Network request started: " + toNet.getNetworkType());

        final long recoveryStartTime = System.currentTimeMillis();

        // Arm RECOVERY_TIMEOUT (10 seconds)
        timeoutRunnable = () -> {
            Log.e(TAG, "[LinkPulse] Network request timed out after " + RECOVERY_TIMEOUT_MS + "ms");
            cleanUpPendingCallback();
            handleRecoveryFailure(fromNet.getNetworkType(), "Network request validation timed out (Exceeded 10s limit)",
                    decision.currentScore, decision.candidateScore, failureProb);
        };
        mainHandler.postDelayed(timeoutRunnable, RECOVERY_TIMEOUT_MS);

        int transportType = toNet.getNetworkType().equalsIgnoreCase("Wi-Fi")
                ? NetworkCapabilities.TRANSPORT_WIFI
                : NetworkCapabilities.TRANSPORT_CELLULAR;

        NetworkRequest request = new NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .addTransportType(transportType)
                .build();

        pendingSwitchCallback = new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(Network network) {
                Log.d(TAG, "[LinkPulse] Network available: " + toNet.getNetworkType());
                mainHandler.removeCallbacks(timeoutRunnable);

                // Application-level network binding where Android permits
                try {
                    connectivityManager.bindProcessToNetwork(network);
                    Log.d(TAG, "[LinkPulse] Application traffic bound to " + toNet.getNetworkType());
                } catch (Exception e) {
                    Log.w(TAG, "Process network binding restricted: " + e.getMessage());
                }

                // Verify Connectivity Handshake before reporting SUCCESS
                transitionState(RecoveryState.VERIFYING, "Verifying connectivity on " + toNet.getNetworkType() + "...");
                Log.d(TAG, "[LinkPulse] Connectivity verification started");

                ConnectivityVerifier.verifyNetwork(network, (isSuccessful, latencyMs, diag) -> {
                    long recoveryElapsed = System.currentTimeMillis() - recoveryStartTime;
                    String recTimeStr = String.format(Locale.US, "%.1fs", recoveryElapsed / 1000.0);

                    if (isSuccessful) {
                        Log.d(TAG, "[LinkPulse] Connectivity verified!");
                        Log.d(TAG, "[LinkPulse] Smart Recovery successful");
                        lastRecoveryTimestamp = System.currentTimeMillis();

                        transitionState(RecoveryState.RECOVERED, "Smart Recovery Successful: Recovered to " + toNet.getNetworkType() + " (" + recTimeStr + ")");

                        RecoveryEvent event = new RecoveryEvent(
                                formatCurrentDate(), fromNet.getNetworkType(), toNet.getNetworkType(),
                                "Autonomous recovery: " + toNet.getNetworkType() + " scored " + decision.candidateScore + " (+ " + decision.improvement + " pts)",
                                failureProb, decision.currentScore, decision.candidateScore, recTimeStr, "SUCCESS"
                        );

                        database.insertEvent(event);
                        ApiClient.postRecoveryEvent(event, null);

                        if (listener != null) {
                            mainHandler.post(() -> listener.onRecoveryCompleted(event));
                        }
                    } else {
                        Log.e(TAG, "[LinkPulse] Verification failed: " + diag);
                        handleRecoveryFailure(fromNet.getNetworkType(), "Handshake verification failed on " + toNet.getNetworkType(),
                                decision.currentScore, decision.candidateScore, failureProb);
                    }
                });
            }

            @Override
            public void onUnavailable() {
                Log.e(TAG, "[LinkPulse] Requested network unavailable");
                mainHandler.removeCallbacks(timeoutRunnable);
                handleRecoveryFailure(fromNet.getNetworkType(), "Requested network transport unavailable on device",
                        decision.currentScore, decision.candidateScore, failureProb);
            }
        };

        try {
            connectivityManager.requestNetwork(request, pendingSwitchCallback);
        } catch (Exception e) {
            Log.e(TAG, "RequestNetwork failed", e);
            mainHandler.removeCallbacks(timeoutRunnable);
            handleRecoveryFailure(fromNet.getNetworkType(), "OS rejected network request: " + e.getMessage(),
                    decision.currentScore, decision.candidateScore, failureProb);
        }
    }

    private void handleRecoveryFailure(String fromNet, String reason, int oldScore, int newScore, int failProb) {
        cleanUpPendingCallback();
        transitionState(RecoveryState.RECOVERY_FAILED, "Smart Recovery Failed: " + reason);

        RecoveryEvent event = new RecoveryEvent(
                formatCurrentDate(), fromNet, "None", reason,
                failProb, oldScore, newScore, "-", "FAILED"
        );
        database.insertEvent(event);
        ApiClient.postRecoveryEvent(event, null);

        if (listener != null) {
            mainHandler.post(() -> listener.onRecoveryCompleted(event));
        }

        // Return to monitoring after 3 seconds
        mainHandler.postDelayed(() -> transitionState(RecoveryState.MONITORING, "Continuous monitoring active"), 3000);
    }

    private void cleanUpPendingCallback() {
        if (pendingSwitchCallback != null) {
            try {
                connectivityManager.unregisterNetworkCallback(pendingSwitchCallback);
            } catch (Exception ignored) {}
            pendingSwitchCallback = null;
        }
    }

    private List<NetworkMetrics> discoverAlternativeCandidates(NetworkMetrics current) {
        List<NetworkMetrics> list = new ArrayList<>();
        String curr = current.getNetworkType();

        // Candidate 5G
        if (!curr.equalsIgnoreCase("5G")) {
            list.add(new NetworkMetrics("5G", -48, 16, 0.2, 3, 90.0, 25.0, true, true));
        }

        // Candidate Wi-Fi
        if (!curr.equalsIgnoreCase("Wi-Fi")) {
            list.add(new NetworkMetrics("Wi-Fi", -52, 20, 0.4, 4, 60.0, 18.0, true, true));
        }

        // Candidate 4G LTE
        if (!curr.equalsIgnoreCase("4G")) {
            list.add(new NetworkMetrics("4G", -66, 45, 1.8, 8, 28.0, 7.0, true, true));
        }

        return list;
    }

    private void transitionState(RecoveryState newState, String message) {
        this.currentState = newState;
        if (listener != null) {
            mainHandler.post(() -> listener.onRecoveryStateChanged(newState, message));
        }
    }

    private String formatCurrentDate() {
        return new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.US).format(new Date());
    }
}
