package com.linkpulse.app;

/**
 * LinkPulse - NetworkQualityScorer
 * Section 7: Computes a standardized multi-attribute Network Quality Score (0 to 100).
 *
 * Formula:
 *   Score = 0.30 * SignalScore + 0.25 * LatencyScore + 0.20 * LossScore
 *         + 0.15 * DownloadScore + 0.10 * StabilityScore
 */
public class NetworkQualityScorer {

    public static final double WEIGHT_SIGNAL = 0.30;
    public static final double WEIGHT_LATENCY = 0.25;
    public static final double WEIGHT_PACKET_LOSS = 0.20;
    public static final double WEIGHT_DOWNLOAD = 0.15;
    public static final double WEIGHT_STABILITY = 0.10;

    /**
     * Calculates the composite network score from a NetworkMetrics object
     */
    public static int calculateScore(NetworkMetrics metrics) {
        if (metrics == null || !metrics.isConnected()) return 0;

        // 1. Signal score: [-110 dBm (0 pts) to -40 dBm (100 pts)]
        double sigScore = ((metrics.getSignalDbm() - (-110.0)) / (-40.0 - (-110.0))) * 100.0;
        sigScore = Math.max(0.0, Math.min(100.0, sigScore));

        // 2. Latency score: [250 ms (0 pts) down to 10 ms (100 pts)]
        double latScore = ((250.0 - metrics.getLatencyMs()) / (250.0 - 10.0)) * 100.0;
        latScore = Math.max(0.0, Math.min(100.0, latScore));

        // 3. Packet loss score: [25% loss (0 pts) down to 0% (100 pts)]
        double lossScore = ((25.0 - metrics.getPacketLossPercent()) / 25.0) * 100.0;
        lossScore = Math.max(0.0, Math.min(100.0, lossScore));

        // 4. Download speed score: [0 Mbps (0 pts) to 100 Mbps (100 pts)]
        double downScore = (metrics.getDownloadSpeedMbps() / 100.0) * 100.0;
        downScore = Math.max(0.0, Math.min(100.0, downScore));

        // 5. Stability score: based on jitter [0-30 ms] and validation status
        double jitterScore = Math.max(0.0, Math.min(100.0, ((30.0 - metrics.getJitterMs()) / 30.0) * 100.0));
        double validationScore = metrics.isValidated() ? 100.0 : 40.0;
        double stabilityScore = (jitterScore * 0.5) + (validationScore * 0.5);

        // Weighted total
        double total = (
                WEIGHT_SIGNAL * sigScore +
                WEIGHT_LATENCY * latScore +
                WEIGHT_PACKET_LOSS * lossScore +
                WEIGHT_DOWNLOAD * downScore +
                WEIGHT_STABILITY * stabilityScore
        );

        return (int) Math.round(Math.max(5.0, Math.min(100.0, total)));
    }
}
