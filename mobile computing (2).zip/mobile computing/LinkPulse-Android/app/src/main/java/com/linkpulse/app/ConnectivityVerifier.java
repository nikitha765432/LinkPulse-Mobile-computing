package com.linkpulse.app;

import android.net.Network;
import android.util.Log;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * LinkPulse - ConnectivityVerifier
 * Section 9 & 13: Verifies actual Internet connectivity on the selected network
 * before marking recovery as successful.
 * "Do NOT show 'Recovered' unless recovery has actually been verified."
 */
public class ConnectivityVerifier {
    private static final String TAG = "LinkPulse-Verifier";
    private static final String VERIFICATION_URL = "http://clients3.google.com/generate_204";
    public static final int TIMEOUT_MS = 6000;

    public interface VerificationCallback {
        void onVerificationResult(boolean isSuccessful, long latencyMs, String diagnosticMessage);
    }

    /**
     * Probes HTTP 204 endpoint through the specific requested Android Network
     */
    public static void verifyNetwork(Network network, VerificationCallback callback) {
        new Thread(() -> {
            long startTime = System.currentTimeMillis();
            HttpURLConnection conn = null;
            try {
                URL url = new URL(VERIFICATION_URL);
                if (network != null) {
                    conn = (HttpURLConnection) network.openConnection(url);
                } else {
                    conn = (HttpURLConnection) url.openConnection();
                }

                conn.setConnectTimeout(TIMEOUT_MS);
                conn.setReadTimeout(TIMEOUT_MS);
                conn.setRequestMethod("GET");
                conn.setInstanceFollowRedirects(false);
                conn.setUseCaches(false);

                Log.d(TAG, "[LinkPulse] Connectivity verification probe started...");
                int responseCode = conn.getResponseCode();
                long latency = System.currentTimeMillis() - startTime;

                if (responseCode == 204 || responseCode == 200) {
                    Log.d(TAG, "[LinkPulse] Connectivity verified in " + latency + "ms (HTTP " + responseCode + ")");
                    if (callback != null) {
                        callback.onVerificationResult(true, latency, "Verified nominal Internet access (HTTP 204).");
                    }
                } else {
                    Log.w(TAG, "[LinkPulse] Captive portal / unexpected response: HTTP " + responseCode);
                    if (callback != null) {
                        callback.onVerificationResult(false, latency, "Unexpected response: HTTP " + responseCode);
                    }
                }

            } catch (IOException e) {
                long latency = System.currentTimeMillis() - startTime;
                Log.e(TAG, "[LinkPulse] Connectivity verification probe failed: " + e.getMessage());
                if (callback != null) {
                    callback.onVerificationResult(false, latency, "Connection handshake failed / timed out.");
                }
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
        }).start();
    }
}
