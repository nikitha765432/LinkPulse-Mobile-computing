package com.linkpulse.app;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * LinkPulse - ApiClient
 * Section 19: Asynchronous HTTP client communicating with LinkPulse REST API.
 * Automatically falls back to on-device processing if the backend is unreachable.
 */
public class ApiClient {
    private static final String TAG = "LinkPulse-API";
    // Default local server address (10.0.2.2 is Android emulator host loopback)
    public static String BASE_URL = "http://10.0.2.2:8080";

    public interface ApiCallback<T> {
        void onSuccess(T result);
        void onError(String errorMessage);
    }

    public static void predict(NetworkMetrics metrics, ApiCallback<FailurePredictionManager.PredictionResult> callback) {
        new Thread(() -> {
            try {
                JSONObject json = new JSONObject();
                json.put("signal_strength", metrics.getSignalDbm());
                json.put("latency", metrics.getLatencyMs());
                json.put("packet_loss", metrics.getPacketLossPercent());
                json.put("network_type", metrics.getNetworkType());

                String resp = executePost("/predict", json.toString());
                JSONObject resObj = new JSONObject(resp);

                double prob = resObj.getDouble("failureProbability");
                String status = resObj.getString("status");
                boolean recReq = resObj.getBoolean("recoveryRequired");
                String explanation = resObj.optString("explanation", "Prediction computed by API");

                FailurePredictionManager.PredictionResult result =
                        new FailurePredictionManager.PredictionResult(prob, status, recReq, explanation);

                postToMainThread(() -> callback.onSuccess(result));
            } catch (Exception e) {
                Log.w(TAG, "API predict failed, fallback to local model: " + e.getMessage());
                // Local fallback
                FailurePredictionManager.PredictionResult localResult = FailurePredictionManager.predict(metrics);
                postToMainThread(() -> callback.onSuccess(localResult));
            }
        }).start();
    }

    public static void postRecoveryEvent(RecoveryEvent event, ApiCallback<Boolean> callback) {
        new Thread(() -> {
            try {
                JSONObject json = new JSONObject();
                json.put("timestamp", event.getTimestamp());
                json.put("previousNetwork", event.getPreviousNetwork());
                json.put("newNetwork", event.getNewNetwork());
                json.put("reason", event.getReason());
                json.put("failureProbability", event.getFailureProbability());
                json.put("oldScore", event.getOldNetworkScore());
                json.put("newScore", event.getNewNetworkScore());
                json.put("recoveryTime", event.getRecoveryTime());
                json.put("result", event.getResult());

                executePost("/recovery/event", json.toString());
                if (callback != null) postToMainThread(() -> callback.onSuccess(true));
            } catch (Exception e) {
                Log.w(TAG, "Post recovery event API failed: " + e.getMessage());
                if (callback != null) postToMainThread(() -> callback.onError(e.getMessage()));
            }
        }).start();
    }

    private static String executePost(String endpoint, String jsonBody) throws Exception {
        URL url = new URL(BASE_URL + endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setConnectTimeout(4000);
        conn.setReadTimeout(4000);
        conn.setDoOutput(true);

        OutputStream os = conn.getOutputStream();
        os.write(jsonBody.getBytes("UTF-8"));
        os.close();

        int responseCode = conn.getResponseCode();
        if (responseCode >= 200 && responseCode < 300) {
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            return sb.toString();
        } else {
            throw new Exception("HTTP error code: " + responseCode);
        }
    }

    private static void postToMainThread(Runnable runnable) {
        new Handler(Looper.getMainLooper()).post(runnable);
    }
}
