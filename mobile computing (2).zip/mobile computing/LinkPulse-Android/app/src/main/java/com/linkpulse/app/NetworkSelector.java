package com.linkpulse.app;

import java.util.List;

/**
 * LinkPulse - NetworkSelector
 * Section 7, 11 & 12: Evaluates discovered candidate networks.
 * Enforces anti-ping-pong logic:
 *   - RECOVERY_COOLDOWN = 30 seconds
 *   - MIN_NETWORK_IMPROVEMENT = 15 points
 */
public class NetworkSelector {

    public static final int MIN_NETWORK_IMPROVEMENT = 15; // 15 points threshold
    public static final long RECOVERY_COOLDOWN_MS = 30000; // 30 seconds cooldown

    public static class SelectionDecision {
        public boolean switchRecommended;
        public NetworkMetrics bestCandidate;
        public int currentScore;
        public int candidateScore;
        public int improvement;
        public String reason;

        public SelectionDecision(boolean switchRecommended, NetworkMetrics bestCandidate,
                                 int currentScore, int candidateScore, int improvement, String reason) {
            this.switchRecommended = switchRecommended;
            this.bestCandidate = bestCandidate;
            this.currentScore = currentScore;
            this.candidateScore = candidateScore;
            this.improvement = improvement;
            this.reason = reason;
        }
    }

    /**
     * Evaluates available candidates against current network conditions
     */
    public static SelectionDecision evaluateCandidates(NetworkMetrics currentMetrics,
                                                       List<NetworkMetrics> candidateNetworks,
                                                       long lastRecoveryTimestamp) {
        int currentScore = NetworkQualityScorer.calculateScore(currentMetrics);
        long now = System.currentTimeMillis();
        long timeSinceLastRecovery = now - lastRecoveryTimestamp;

        // Anti ping-pong cooldown check
        if (lastRecoveryTimestamp > 0 && timeSinceLastRecovery < RECOVERY_COOLDOWN_MS) {
            long remainingSec = (RECOVERY_COOLDOWN_MS - timeSinceLastRecovery) / 1000;
            return new SelectionDecision(false, null, currentScore, currentScore, 0,
                    String.format("Switch suppressed: Cooldown active (%ds remaining to prevent ping-pong oscillation).", remainingSec));
        }

        if (candidateNetworks == null || candidateNetworks.isEmpty()) {
            return new SelectionDecision(false, null, currentScore, currentScore, 0,
                    "No alternative network candidates available on the device.");
        }

        NetworkMetrics bestCandidate = null;
        int bestScore = -1;

        for (NetworkMetrics candidate : candidateNetworks) {
            // Ignore candidate if it is identical to current network type
            if (candidate.getNetworkType().equalsIgnoreCase(currentMetrics.getNetworkType())) {
                continue;
            }

            int score = NetworkQualityScorer.calculateScore(candidate);
            if (score > bestScore) {
                bestScore = score;
                bestCandidate = candidate;
            }
        }

        if (bestCandidate == null) {
            return new SelectionDecision(false, null, currentScore, currentScore, 0,
                    "No distinct candidate network found.");
        }

        int improvement = bestScore - currentScore;

        // Minimum improvement threshold check (15 pts)
        if (improvement < MIN_NETWORK_IMPROVEMENT) {
            return new SelectionDecision(false, bestCandidate, currentScore, bestScore, improvement,
                    String.format("Best alternative (%s, score %d) does not meet minimum improvement threshold (+%d pts required, actual: +%d pts).",
                            bestCandidate.getNetworkType(), bestScore, MIN_NETWORK_IMPROVEMENT, improvement));
        }

        return new SelectionDecision(true, bestCandidate, currentScore, bestScore, improvement,
                String.format("Autonomous switch recommended: %s (score %d) offers +%d pts higher connectivity quality over %s (score %d).",
                        bestCandidate.getNetworkType(), bestScore, improvement, currentMetrics.getNetworkType(), currentScore));
    }
}
