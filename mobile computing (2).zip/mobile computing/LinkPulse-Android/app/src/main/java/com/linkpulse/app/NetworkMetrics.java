package com.linkpulse.app;

import java.io.Serializable;

/**
 * LinkPulse - NetworkMetrics Data Model
 * Encapsulates real-time radio telemetry, link parameters, and transport state.
 */
public class NetworkMetrics implements Serializable {
    private String networkType;         // "Wi-Fi", "5G", "4G", "3G", "None"
    private int signalDbm;              // RSSI / RSRP in dBm (e.g. -65 dBm)
    private int latencyMs;              // Round-Trip Delay in ms (e.g. 45 ms)
    private double packetLossPercent;   // Packet loss percentage (e.g. 2.0%)
    private int jitterMs;               // Latency jitter in ms (e.g. 10 ms)
    private double downloadSpeedMbps;   // Downlink throughput (e.g. 35.0 Mbps)
    private double uploadSpeedMbps;     // Uplink throughput (e.g. 8.0 Mbps)
    private boolean isConnected;        // Socket / Interface online status
    private boolean isValidated;        // Has verified Internet access
    private long timestamp;             // Timestamp in epoch millis

    public NetworkMetrics() {
        this.networkType = "Wi-Fi";
        this.signalDbm = -65;
        this.latencyMs = 45;
        this.packetLossPercent = 2.0;
        this.jitterMs = 10;
        this.downloadSpeedMbps = 35.0;
        this.uploadSpeedMbps = 8.0;
        this.isConnected = true;
        this.isValidated = true;
        this.timestamp = System.currentTimeMillis();
    }

    public NetworkMetrics(String networkType, int signalDbm, int latencyMs, double packetLossPercent,
                          int jitterMs, double downloadSpeedMbps, double uploadSpeedMbps,
                          boolean isConnected, boolean isValidated) {
        this.networkType = networkType;
        this.signalDbm = signalDbm;
        this.latencyMs = latencyMs;
        this.packetLossPercent = packetLossPercent;
        this.jitterMs = jitterMs;
        this.downloadSpeedMbps = downloadSpeedMbps;
        this.uploadSpeedMbps = uploadSpeedMbps;
        this.isConnected = isConnected;
        this.isValidated = isValidated;
        this.timestamp = System.currentTimeMillis();
    }

    // Getters and Setters
    public String getNetworkType() { return networkType; }
    public void setNetworkType(String networkType) { this.networkType = networkType; }

    public int getSignalDbm() { return signalDbm; }
    public void setSignalDbm(int signalDbm) { this.signalDbm = signalDbm; }

    public int getLatencyMs() { return latencyMs; }
    public void setLatencyMs(int latencyMs) { this.latencyMs = latencyMs; }

    public double getPacketLossPercent() { return packetLossPercent; }
    public void setPacketLossPercent(double packetLossPercent) { this.packetLossPercent = packetLossPercent; }

    public int getJitterMs() { return jitterMs; }
    public void setJitterMs(int jitterMs) { this.jitterMs = jitterMs; }

    public double getDownloadSpeedMbps() { return downloadSpeedMbps; }
    public void setDownloadSpeedMbps(double downloadSpeedMbps) { this.downloadSpeedMbps = downloadSpeedMbps; }

    public double getUploadSpeedMbps() { return uploadSpeedMbps; }
    public void setUploadSpeedMbps(double uploadSpeedMbps) { this.uploadSpeedMbps = uploadSpeedMbps; }

    public boolean isConnected() { return isConnected; }
    public void setConnected(boolean connected) { isConnected = connected; }

    public boolean isValidated() { return isValidated; }
    public void setValidated(boolean validated) { isValidated = validated; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    @Override
    public String toString() {
        return "NetworkMetrics{" +
                "type='" + networkType + '\'' +
                ", signal=" + signalDbm + " dBm" +
                ", latency=" + latencyMs + " ms" +
                ", loss=" + packetLossPercent + "%" +
                ", jitter=" + jitterMs + " ms" +
                ", dn=" + downloadSpeedMbps + " Mbps" +
                ", up=" + uploadSpeedMbps + " Mbps" +
                ", connected=" + isConnected +
                '}';
    }
}
