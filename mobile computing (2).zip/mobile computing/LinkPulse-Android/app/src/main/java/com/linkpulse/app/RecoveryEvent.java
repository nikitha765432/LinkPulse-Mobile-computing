package com.linkpulse.app;

import java.io.Serializable;

/**
 * LinkPulse - RecoveryEvent Data Model
 * Section 18: Audits recovery actions with exact timestamps, networks, scores, and verification outcomes.
 */
public class RecoveryEvent implements Serializable {
    private long id;
    private String timestamp;           // Formatted date string (e.g. "23-11-2026 12:35")
    private String previousNetwork;      // e.g. "Wi-Fi"
    private String newNetwork;           // e.g. "5G"
    private String reason;               // e.g. "High packet loss & predictive failure"
    private int failureProbability;      // e.g. 84%
    private int oldNetworkScore;         // e.g. 42
    private int newNetworkScore;         // e.g. 88
    private String recoveryTime;         // e.g. "1.8s"
    private String result;               // "SUCCESS", "FAILED", "NO_SWITCH"

    public RecoveryEvent() {}

    public RecoveryEvent(String timestamp, String previousNetwork, String newNetwork, String reason,
                         int failureProbability, int oldNetworkScore, int newNetworkScore,
                         String recoveryTime, String result) {
        this.timestamp = timestamp;
        this.previousNetwork = previousNetwork;
        this.newNetwork = newNetwork;
        this.reason = reason;
        this.failureProbability = failureProbability;
        this.oldNetworkScore = oldNetworkScore;
        this.newNetworkScore = newNetworkScore;
        this.recoveryTime = recoveryTime;
        this.result = result;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }

    public String getPreviousNetwork() { return previousNetwork; }
    public void setPreviousNetwork(String previousNetwork) { this.previousNetwork = previousNetwork; }

    public String getNewNetwork() { return newNetwork; }
    public void setNewNetwork(String newNetwork) { this.newNetwork = newNetwork; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public int getFailureProbability() { return failureProbability; }
    public void setFailureProbability(int failureProbability) { this.failureProbability = failureProbability; }

    public int getOldNetworkScore() { return oldNetworkScore; }
    public void setOldNetworkScore(int oldNetworkScore) { this.oldNetworkScore = oldNetworkScore; }

    public int getNewNetworkScore() { return newNetworkScore; }
    public void setNewNetworkScore(int newNetworkScore) { this.newNetworkScore = newNetworkScore; }

    public String getRecoveryTime() { return recoveryTime; }
    public void setRecoveryTime(String recoveryTime) { this.recoveryTime = recoveryTime; }

    public String getResult() { return result; }
    public void setResult(String result) { this.result = result; }
}
