package com.linkpulse.app;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.telephony.TelephonyManager;

/**
 * LinkPulse - NetworkTypeDetector
 * Section 3: Inspects real device network capabilities and telephony transport.
 * Differentiates Wi-Fi, 5G NR, 4G LTE, 3G, and Ethernet without assuming 5G is always present.
 */
public class NetworkTypeDetector {

    public static String detectActiveNetworkType(Context context) {
        if (context == null) return "None";

        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return "None";

            Network activeNetwork = cm.getActiveNetwork();
            if (activeNetwork == null) return "None";

            NetworkCapabilities capabilities = cm.getNetworkCapabilities(activeNetwork);
            if (capabilities == null) return "None";

            // 1. Wi-Fi Transport
            if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                return "Wi-Fi";
            }

            // 2. Cellular / Mobile Transport
            if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                return detectCellularGeneration(context);
            }

            // 3. Ethernet
            if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                return "Ethernet";
            }

            return "Mobile";
        } catch (Exception e) {
            return "Wi-Fi"; // Safe fallback
        }
    }

    /**
     * Inspects TelephonyManager data network type to determine 5G, 4G, or 3G
     */
    private static String detectCellularGeneration(Context context) {
        try {
            TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return "4G";

            int networkType = TelephonyManager.NETWORK_TYPE_UNKNOWN;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                try {
                    networkType = tm.getDataNetworkType();
                } catch (SecurityException ignored) {
                    // Requires READ_PHONE_STATE on some API levels; gracefully fallback
                }
            }

            switch (networkType) {
                // 5G NR (New Radio) - API 29+
                case 20: // TelephonyManager.NETWORK_TYPE_NR
                    return "5G";

                // 4G LTE
                case TelephonyManager.NETWORK_TYPE_LTE:
                    return "4G";

                // 3G Transports
                case TelephonyManager.NETWORK_TYPE_HSDPA:
                case TelephonyManager.NETWORK_TYPE_HSPA:
                case TelephonyManager.NETWORK_TYPE_HSPAP:
                case TelephonyManager.NETWORK_TYPE_HSUPA:
                case TelephonyManager.NETWORK_TYPE_UMTS:
                    return "3G";

                // 2G / Legacy
                case TelephonyManager.NETWORK_TYPE_EDGE:
                case TelephonyManager.NETWORK_TYPE_GPRS:
                    return "2G";

                default:
                    return "4G"; // Default modern mobile baseline
            }
        } catch (Exception e) {
            return "4G";
        }
    }
}
