package com.linkpulse.app;

/**
 * LinkPulse - FailurePredictionManager
 * Section 5 & 6: Client-side Predictive Failure Inference Engine.
 * Evaluates real-time RF attenuation, latency inflation, and packet loss
 * to predict connectivity failures before dropped sockets occur.
 */
public class FailurePredictionManager {

    public static final double HIGH_RISK_THRESHOLD = 0.70; // 70% failure probability triggers recovery
    public static final double WARNING_THRESHOLD = 0.40;   // 40% warning

    public static class PredictionResult {
        public double failureProbability;     // 0.0 - 1.0
        public int failureProbabilityPercent; // 0 - 100%
        public String status;                 // "GOOD", "WARNING", "HIGH_RISK"
        public boolean recoveryRequired;      // True if probability >= HIGH_RISK_THRESHOLD
        public String explanation;

        public PredictionResult(double failureProbability, String status, boolean recoveryRequired, String explanation) {
            this.failureProbability = failureProbability;
            this.failureProbabilityPercent = (int) Math.round(failureProbability * 100.0);
            this.status = status;
            this.recoveryRequired = recoveryRequired;
            this.explanation = explanation;
        }
    }

    /**
     * Evaluates current network metrics using synthetic dataset feature bounds
     */
    public static PredictionResult predict(NetworkMetrics metrics) {
        if (metrics == null || !metrics.isConnected()) {
            return new PredictionResult(1.0, "HIGH_RISK", true,
                    "Link interface disconnected. Immediate recovery required.");
        }

        int sig = metrics.getSignalDbm();
        int lat = metrics.getLatencyMs();
        double loss = metrics.getPacketLossPercent();
        int jitter = metrics.getJitterMs();

        // 1. High Risk Criteria (matches Unstable / High Risk rows in network_data.csv)
        // e.g., signal < -80 dBm, latency > 100 ms, loss > 6%
        if (sig < -80 || lat > 110 || loss > 8.0) {
            double sigPenalty = Math.max(0.0, (Math.abs(sig) - 80) * 0.015);
            double latPenalty = Math.max(0.0, (lat - 100) * 0.002);
            double lossPenalty = Math.max(0.0, (loss - 8.0) * 0.015);

            double prob = Math.min(0.96, 0.72 + sigPenalty + latPenalty + lossPenalty);
            return new PredictionResult(prob, "HIGH_RISK", true,
                    String.format("Critical attenuation (%d dBm) and latency (%d ms) indicate imminent link failure.", sig, lat));
        }

        // 2. Warning / Degraded Criteria
        // e.g., signal between -68 and -80 dBm, latency between 55 and 110 ms
        if (sig < -68 || lat > 55 || loss > 2.5 || jitter > 12) {
            double prob = 0.45 + (Math.abs(sig) - 68) * 0.01 + (lat - 55) * 0.002;
            prob = Math.max(0.35, Math.min(0.68, prob));
            return new PredictionResult(prob, "WARNING", false,
                    String.format("Moderate link degradation detected (%d dBm, %d ms RTT). Connection remains usable.", sig, lat));
        }

        // 3. Good / Stable Condition
        double prob = Math.max(0.08, 0.15 - (Math.abs(sig) - 45) * 0.002);
        return new PredictionResult(prob, "GOOD", false,
                "Network parameters are nominal. No signs of degradation.");
    }
}
