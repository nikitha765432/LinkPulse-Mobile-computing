package com.linkpulse.app;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * LinkPulse - MainActivity Dashboard
 * Section 14, 15, 24: Primary User Interface.
 * Real-time monitoring metrics, failure prediction displays, Smart Recovery card,
 * interactive Viva test scenarios, and persistent recovery history audit log.
 */
public class MainActivity extends AppCompatActivity implements
        NetworkMonitor.OnNetworkUpdateListener,
        RecoveryManager.OnRecoveryListener {

    private NetworkMonitor networkMonitor;
    private RecoveryManager recoveryManager;
    private RecoveryDatabase database;

    // UI Elements
    private TextView tvConnectionStatus;
    private TextView tvCurrentNetwork;
    private TextView tvSignal;
    private TextView tvLatency;
    private TextView tvPacketLoss;
    private TextView tvJitter;
    private TextView tvDownload;
    private TextView tvUpload;
    private TextView tvFailureProbability;
    private TextView tvNetworkHealth;
    private TextView tvSmartRecoveryState;
    private TextView tvRecoveryDetails;
    private ProgressBar pbRecoveryProgress;

    private Button btnStartMonitoring;
    private Button btnStopMonitoring;
    private Button btnTestRecovery;
    private Button btnViewHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize core engine components
        database = new RecoveryDatabase(this);
        networkMonitor = new NetworkMonitor(this);
        recoveryManager = new RecoveryManager(this, database);

        networkMonitor.setListener(this);
        recoveryManager.setListener(this);

        initViews();
        setupButtonListeners();

        // Start continuous monitoring by default
        networkMonitor.startMonitoring();
    }

    private void initViews() {
        tvConnectionStatus = findViewById(R.id.tvConnectionStatus);
        tvCurrentNetwork = findViewById(R.id.tvCurrentNetwork);
        tvSignal = findViewById(R.id.tvSignal);
        tvLatency = findViewById(R.id.tvLatency);
        tvPacketLoss = findViewById(R.id.tvPacketLoss);
        tvJitter = findViewById(R.id.tvJitter);
        tvDownload = findViewById(R.id.tvDownload);
        tvUpload = findViewById(R.id.tvUpload);
        tvFailureProbability = findViewById(R.id.tvFailureProbability);
        tvNetworkHealth = findViewById(R.id.tvNetworkHealth);
        tvSmartRecoveryState = findViewById(R.id.tvSmartRecoveryState);
        tvRecoveryDetails = findViewById(R.id.tvRecoveryDetails);
        pbRecoveryProgress = findViewById(R.id.pbRecoveryProgress);

        btnStartMonitoring = findViewById(R.id.btnStartMonitoring);
        btnStopMonitoring = findViewById(R.id.btnStopMonitoring);
        btnTestRecovery = findViewById(R.id.btnTestRecovery);
        btnViewHistory = findViewById(R.id.btnViewHistory);
    }

    private void setupButtonListeners() {
        btnStartMonitoring.setOnClickListener(v -> {
            networkMonitor.startMonitoring();
            Toast.makeText(this, "[LinkPulse] Continuous monitoring started", Toast.LENGTH_SHORT).show();
        });

        btnStopMonitoring.setOnClickListener(v -> {
            networkMonitor.stopMonitoring();
            tvSmartRecoveryState.setText("MONITORING PAUSED");
            Toast.makeText(this, "[LinkPulse] Monitoring paused", Toast.LENGTH_SHORT).show();
        });

        btnTestRecovery.setOnClickListener(v -> showTestRecoveryDialog());

        btnViewHistory.setOnClickListener(v -> showHistoryDialog());
    }

    @Override
    public void onNetworkMetricsUpdated(NetworkMetrics metrics) {
        runOnUiThread(() -> {
            tvCurrentNetwork.setText(metrics.getNetworkType());
            tvSignal.setText(metrics.getSignalDbm() + " dBm");
            tvLatency.setText(metrics.getLatencyMs() + " ms");
            tvPacketLoss.setText(String.format(java.util.Locale.US, "%.1f%%", metrics.getPacketLossPercent()));
            tvJitter.setText(metrics.getJitterMs() + " ms");
            tvDownload.setText(String.format(java.util.Locale.US, "%.1f Mbps", metrics.getDownloadSpeedMbps()));
            tvUpload.setText(String.format(java.util.Locale.US, "%.1f Mbps", metrics.getUploadSpeedMbps()));

            // Predict failure risk
            FailurePredictionManager.PredictionResult pred = FailurePredictionManager.predict(metrics);
            tvFailureProbability.setText(pred.failureProbabilityPercent + "%");
            tvNetworkHealth.setText(pred.status);

            if (metrics.isConnected()) {
                tvConnectionStatus.setText("CONNECTED");
                tvConnectionStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            } else {
                tvConnectionStatus.setText("FAILED");
                tvConnectionStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            }

            // Feed metrics into RecoveryManager
            recoveryManager.processMetrics(metrics);
        });
    }

    @Override
    public void onNetworkLost(String networkType) {
        runOnUiThread(() -> {
            tvConnectionStatus.setText("FAILED (DISCONNECTED)");
            tvConnectionStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            Toast.makeText(this, "[LinkPulse] Network link lost: " + networkType, Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onRecoveryStateChanged(RecoveryManager.RecoveryState state, String statusMessage) {
        runOnUiThread(() -> {
            tvSmartRecoveryState.setText(state.name());
            tvRecoveryDetails.setText(statusMessage);

            if (state == RecoveryManager.RecoveryState.SWITCHING || state == RecoveryManager.RecoveryState.VERIFYING) {
                pbRecoveryProgress.setVisibility(View.VISIBLE);
            } else {
                pbRecoveryProgress.setVisibility(View.GONE);
            }

            if (state == RecoveryManager.RecoveryState.RECOVERED) {
                tvConnectionStatus.setText("RECOVERED");
                tvConnectionStatus.setTextColor(getResources().getColor(android.R.color.holo_blue_dark));
            } else if (state == RecoveryManager.RecoveryState.RECOVERY_FAILED) {
                tvConnectionStatus.setText("RECOVERY FAILED");
                tvConnectionStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            }
        });
    }

    @Override
    public void onCandidatesEvaluated(List<NetworkMetrics> candidates, NetworkMetrics selected) {
        runOnUiThread(() -> {
            if (selected != null) {
                tvRecoveryDetails.setText(String.format(java.util.Locale.US,
                        "Candidates: %d discovered • Selected Best: %s", candidates.size(), selected.getNetworkType()));
            }
        });
    }

    @Override
    public void onRecoveryCompleted(RecoveryEvent event) {
        runOnUiThread(() -> {
            Toast.makeText(this, String.format(java.util.Locale.US,
                    "[LinkPulse] Recovery Result: %s (%s -> %s)", event.getResult(), event.getPreviousNetwork(), event.getNewNetwork()), Toast.LENGTH_LONG).show();
        });
    }

    /**
     * Section 24: Test Recovery Dialog for Viva Demonstrations
     */
    private void showTestRecoveryDialog() {
        String[] options = {
                "TEST 1: Stable Wi-Fi (No Recovery Triggered)",
                "TEST 2: Wi-Fi High Latency (Warning Condition)",
                "TEST 3: Wi-Fi Severe Loss -> Recover to 5G",
                "TEST 4: 5G Degraded -> Reverse Recovery to Wi-Fi",
                "TEST 5: Poor Link + No Alternative (Failure)",
                "TEST 6: Candidate Only +5 pts (Anti-Ping-Pong Suppressed)",
                "TEST 7: Request Timeout Simulation (10s Failure)",
                "TEST 8: Full Success Recovery Demonstration"
        };

        new AlertDialog.Builder(this)
                .setTitle("Select Viva Test Scenario (Section 24)")
                .setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 0: // TEST 1
                            onNetworkMetricsUpdated(new NetworkMetrics("Wi-Fi", -52, 22, 0.4, 3, 50.0, 15.0, true, true));
                            break;
                        case 1: // TEST 2
                            onNetworkMetricsUpdated(new NetworkMetrics("Wi-Fi", -72, 125, 4.2, 18, 14.0, 3.5, true, true));
                            break;
                        case 2: // TEST 3
                            onNetworkMetricsUpdated(new NetworkMetrics("Wi-Fi", -88, 230, 27.0, 28, 1.8, 0.4, true, true));
                            break;
                        case 3: // TEST 4
                            onNetworkMetricsUpdated(new NetworkMetrics("5G", -94, 195, 22.0, 24, 3.2, 0.8, true, true));
                            break;
                        case 4: // TEST 5
                            onNetworkMetricsUpdated(new NetworkMetrics("Wi-Fi", -95, 250, 35.0, 30, 0.5, 0.1, true, false));
                            break;
                        case 5: // TEST 6
                            onNetworkMetricsUpdated(new NetworkMetrics("4G", -70, 60, 2.0, 8, 20.0, 5.0, true, true));
                            break;
                        case 6: // TEST 7
                            onNetworkMetricsUpdated(new NetworkMetrics("Wi-Fi", -90, 240, 28.0, 25, 1.5, 0.3, true, true));
                            break;
                        case 7: // TEST 8
                            onNetworkMetricsUpdated(new NetworkMetrics("Wi-Fi", -86, 215, 23.0, 26, 2.4, 0.6, true, true));
                            break;
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * History Dialog showing SQLite records
     */
    private void showHistoryDialog() {
        List<RecoveryEvent> history = database.getAllEvents();
        StringBuilder sb = new StringBuilder();

        for (RecoveryEvent e : history) {
            sb.append(e.getTimestamp()).append(" • ")
                    .append(e.getPreviousNetwork()).append(" -> ").append(e.getNewNetwork()).append("\n")
                    .append("Score: ").append(e.getOldNetworkScore()).append(" -> ").append(e.getNewNetworkScore())
                    .append(" (").append(e.getRecoveryTime()).append(") [").append(e.getResult()).append("]\n")
                    .append("Reason: ").append(e.getReason()).append("\n\n");
        }

        if (history.isEmpty()) {
            sb.append("No recovery events logged yet.");
        }

        new AlertDialog.Builder(this)
                .setTitle("Audited Recovery History (Section 18)")
                .setMessage(sb.toString())
                .setPositiveButton("Close", null)
                .setNeutralButton("Clear History", (dialog, which) -> {
                    database.clearHistory();
                    Toast.makeText(this, "Recovery history cleared", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (networkMonitor != null) {
            networkMonitor.stopMonitoring();
        }
    }
}
