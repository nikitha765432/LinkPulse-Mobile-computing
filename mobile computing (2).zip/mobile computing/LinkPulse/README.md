# LinkPulse – Predictive Mobile Connectivity Failure Detection and Smart Recovery System

LinkPulse is an intelligent, multi-transport mobile connectivity monitoring and autonomous recovery system designed for academic demonstration and B.Tech mobile computing reviews.

It proactively monitors connection telemetry, predicts imminent connectivity failures using machine learning trained on network telemetry data, discovers and evaluates candidate networks (Wi-Fi, 4G LTE, 5G NR), calculates multi-attribute Network Quality Scores, and autonomously requests and verifies the optimal network route through supported Android APIs.

---

## 🏗️ Complete Project Structure

```text
mobile computing/
│
├── index.html                           <-- Root launcher redirecting to Web Dashboard
│
├── LinkPulse/                           <-- Web Application & Dataset Engine (VS Code Live Server)
│   ├── index.html                       <-- Module 0: Central Telemetry Cockpit
│   ├── monitor.html                     <-- Module 1: Continuous Multi-Transport Monitoring
│   ├── prediction.html                  <-- Module 2: KNN Dataset-Driven Failure Prediction
│   ├── recovery.html                    <-- Module 3: Smart Recovery Dashboard & Test Suite
│   ├── css/
│   │   └── style.css                    <-- Professional Dark-Navy & White Card UI Stylesheet
│   ├── data/
│   │   └── network_data.csv             <-- Synthetic Telemetry Dataset (400 records, 8 features)
│   ├── js/
│   │   ├── dataset.js                   <-- CSV Parser, Z-Score Standardizer, KNN & Quality Scorer
│   │   ├── main.js                      <-- Shared State Manager, Browser API & Event Bus
│   │   ├── monitor.js                   <-- Telemetry Sampling, Viva Presets & Model Inference
│   │   ├── prediction.js                <-- Feature Slider Controller & Nearest Neighbors Matrix
│   │   └── recovery.js                  <-- 5-Stage Remediation Pipeline, Candidates, & History
│   └── server/
│       └── api_server.py                <-- Lightweight Python REST API (Zero external dependencies)
│
└── LinkPulse-Android/                   <-- Native Android Studio Project
    ├── build.gradle                     <-- Root Project Gradle Build Script
    ├── settings.gradle                  <-- Subproject settings (includes ':app')
    └── app/
        ├── build.gradle                 <-- App Module Gradle Script (compileSdk 34, minSdk 24)
        └── src/main/
            ├── AndroidManifest.xml      <-- Permissions & Launcher Activity
            ├── assets/
            │   └── network_data.csv     <-- Embedded academic dataset
            ├── java/com/linkpulse/app/
            │   ├── MainActivity.java                <-- Dashboard UI Controller & Test Scenarios
            │   ├── NetworkMonitor.java              <-- Real-time NetworkCallback & Polling Layer
            │   ├── NetworkMetrics.java              <-- Telemetry Data Model
            │   ├── NetworkTypeDetector.java         <-- Wi-Fi, 5G, 4G, 3G Transport Inspection
            │   ├── FailurePredictionManager.java    <-- Client-Side Predictive Failure Inference
            │   ├── NetworkQualityScorer.java        <-- Weighted Multi-Attribute Scorer
            │   ├── NetworkSelector.java             <-- Candidate Evaluation & Anti-Ping-Pong
            │   ├── RecoveryManager.java             <-- 8-State Autonomous Recovery Coordinator
            │   ├── RecoveryEvent.java               <-- Recovery Audit Log Entity
            │   ├── RecoveryDatabase.java            <-- Local SQLite Persistence Helper
            │   ├── ApiClient.java                   <-- Async REST Client with Local Fallback
            │   └── ConnectivityVerifier.java        <-- HTTP 204 Socket Verification Probe
            └── res/
                ├── drawable/bg_card.xml
                ├── layout/activity_main.xml
                └── values/
                    ├── colors.xml
                    ├── strings.xml
                    └── themes.xml
```

---

## ⚡ Core Architecture & Operational Flow

```text
CURRENT NETWORK (Wi-Fi / 4G / 5G)
       ↓
CONTINUOUS MONITORING LAYER (NetworkMonitor)
       ↓
COLLECT NETWORK METRICS (Signal, Latency, Loss, Jitter, Bandwidth)
       ↓
FEATURE PROCESSING & PREDICTIVE MODEL (KNN Inference)
       ↓
IS FAILURE RISK HIGH? (Probability ≥ 70%)
       ↓ YES
SEARCH AVAILABLE ALTERNATIVE NETWORKS (Candidates: Wi-Fi, 4G, 5G)
       ↓
EVALUATE NETWORK QUALITY (NetworkQualityScorer)
       Score = 0.30×Signal + 0.25×Latency + 0.20×Loss + 0.15×Download + 0.10×Stability
       ↓
SELECT BEST AVAILABLE NETWORK (NetworkSelector)
       [Enforces: MIN_IMPROVEMENT ≥ 15 pts & COOLDOWN = 30s]
       ↓
REQUEST / USE SELECTED NETWORK (ConnectivityManager & NetworkRequest)
       ↓
VERIFY CONNECTIVITY (ConnectivityVerifier: HTTP 204 Probe, TIMEOUT = 10s)
       ↓
SMART RECOVERY SUCCESSFUL (Reported & Logged to SQLite & localStorage)
       ↓
CONTINUE CONTINUOUS MONITORING
```

---

## 📊 Dataset Integration (`data/network_data.csv`)

- **Attribution**: *Synthetic Network Monitoring Dataset for Academic Demonstration*
- **Records**: 400 calibrated rows across diverse radio fading conditions.
- **Features Used (8 Features)**:
  1. `signal_strength` (-115 dBm to -45 dBm)
  2. `latency` (12 ms to 240 ms)
  3. `packet_loss` (0.0% to 30.0%)
  4. `jitter` (1 ms to 38 ms)
  5. `download_speed` (0.5 Mbps to 100 Mbps)
  6. `upload_speed` (0.1 Mbps to 30 Mbps)
  7. `network_load` (10% to 95%)
  8. `network_type` (Wi-Fi, 5G, 4G, 3G)
- **Target Classes**:
  - `failure_risk`: `Low`, `Medium`, `High`
  - `connection_status`: `Stable`, `Degraded`, `Unstable`

---

## 📱 How to Run the Android Application

1. Open **Android Studio** (Flamingo, Giraffe, Hedgehog, or newer).
2. Select **File → Open...** and navigate to the directory:
   `c:\Users\thang\OneDrive\Desktop\mobile computing\LinkPulse-Android`.
3. Allow Gradle to sync dependencies (`androidx.appcompat`, `material`, `constraintlayout`).
4. Connect an Android phone via USB debugging OR launch an Android Virtual Device (AVD Emulator running API 26 to 34).
5. Click **Run → Run 'app'** (`Shift + F10`).
6. The LinkPulse app will launch with continuous monitoring active.
7. Click **TEST RECOVERY** to run any of the 8 controlled academic test scenarios.

---

## 💻 How to Run the Web Dashboard in VS Code

1. In VS Code, open the folder: `c:\Users\thang\OneDrive\Desktop\mobile computing`.
2. Right-click `index.html` (or `LinkPulse/index.html`) and select **Open with Live Server**.
3. The dashboard opens at `http://127.0.0.1:5500/LinkPulse/`.
4. Navigate through:
   - **Dashboard**: Live overview & telemetry status.
   - **Network Monitor**: 8-metric real-time grid, viva presets, manual sliders, and KNN prediction check.
   - **Prediction**: Interactive 8-feature parameter tuning and nearest neighbors matrix.
   - **Smart Recovery**: 5-stage automated remediation pipeline, alternative network candidate evaluation matrix, and Section 24 test scenario buttons.

---

## 🌐 How to Run the Optional REST API Server

A lightweight Python REST server is included under `LinkPulse/server/api_server.py`:
```powershell
python LinkPulse\server\api_server.py
```
- Listens on `http://0.0.0.0:8080`.
- Provides `/predict`, `/network/metrics`, `/recovery/evaluate`, `/recovery/event`, and `/recovery/history`.
- The Android app and Web dashboard automatically detect and communicate with this server, but gracefully fall back to standalone client-side execution if the server is offline!
