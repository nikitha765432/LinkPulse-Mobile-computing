"""
LinkPulse - Lightweight Recovery & Telemetry REST API Server
Section 19: Provides REST endpoints for Android and Web clients:
  - POST /predict
  - POST /network/metrics
  - POST /recovery/evaluate
  - POST /recovery/event
  - GET  /recovery/history

Uses standard library http.server (Zero external dependencies).
"""

import json
import os
import sys
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
import datetime

HOST = '0.0.0.0'
PORT = 8080

# In-memory history store (synchronized with SQLite on Android)
RECOVERY_HISTORY = [
    {
        "id": 1,
        "timestamp": "23-11-2026 12:35:10",
        "previousNetwork": "Wi-Fi",
        "newNetwork": "5G",
        "reason": "High packet loss & severe RF fading",
        "failureProbability": 86,
        "oldScore": 38,
        "newScore": 89,
        "recoveryTime": "1.8s",
        "result": "SUCCESS"
    },
    {
        "id": 2,
        "timestamp": "23-11-2026 12:20:45",
        "previousNetwork": "5G",
        "newNetwork": "Wi-Fi",
        "reason": "Reverse Recovery: 5G congestion, 5GHz Wi-Fi superior",
        "failureProbability": 74,
        "oldScore": 45,
        "newScore": 84,
        "recoveryTime": "1.9s",
        "result": "SUCCESS"
    }
]

def calculate_score(metrics):
    sig = float(metrics.get('signal_strength', metrics.get('signalDbm', -70)))
    lat = float(metrics.get('latency', metrics.get('latencyMs', 50)))
    loss = float(metrics.get('packet_loss', metrics.get('packetLoss', 1.5)))
    down = float(metrics.get('download_speed', metrics.get('downloadMbps', 25.0)))
    jitter = float(metrics.get('jitter', metrics.get('jitterMs', 5.0)))
    fail_prob = float(metrics.get('failure_probability', metrics.get('failureProbability', 20.0)))

    sig_score = max(0.0, min(100.0, ((sig - (-110.0)) / (-40.0 - (-110.0))) * 100.0))
    lat_score = max(0.0, min(100.0, ((250.0 - lat) / (250.0 - 10.0)) * 100.0))
    loss_score = max(0.0, min(100.0, ((25.0 - loss) / 25.0) * 100.0))
    down_score = max(0.0, min(100.0, (down / 100.0) * 100.0))
    jitter_score = max(0.0, min(100.0, ((30.0 - jitter) / 30.0) * 100.0))
    stability_score = jitter_score * 0.5 + (100.0 - fail_prob) * 0.5

    total = (
        0.30 * sig_score +
        0.25 * lat_score +
        0.20 * loss_score +
        0.15 * down_score +
        0.10 * stability_score
    )
    return round(max(5, min(100, total)))


class LinkPulseRequestHandler(BaseHTTPRequestHandler):
    def _send_cors_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')

    def do_OPTIONS(self):
        self.send_response(204)
        self._send_cors_headers()
        self.end_headers()

    def _send_json(self, status_code, data):
        self.send_response(status_code)
        self._send_cors_headers()
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))

    def _read_json(self):
        content_length = int(self.headers.get('Content-Length', 0))
        if content_length > 0:
            body = self.rfile.read(content_length).decode('utf-8')
            return json.loads(body)
        return {}

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == '/recovery/history':
            self._send_json(200, {
                "status": "success",
                "count": len(RECOVERY_HISTORY),
                "history": RECOVERY_HISTORY
            })
        elif path == '/health' or path == '/':
            self._send_json(200, {
                "service": "LinkPulse REST API",
                "status": "active",
                "timestamp": datetime.datetime.now().isoformat()
            })
        else:
            self._send_json(404, {"error": "Endpoint not found"})

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        body = self._read_json()

        if path == '/predict':
            # Failure prediction endpoint
            sig = float(body.get('signal_strength', body.get('signalDbm', -65)))
            lat = float(body.get('latency', body.get('latencyMs', 45)))
            loss = float(body.get('packet_loss', body.get('packetLoss', 1.5)))

            if sig < -80 or lat > 100 or loss > 15:
                prob = min(98, round(65 + abs(sig + 80) * 0.8 + (lat - 100) * 0.15))
                status = "HIGH_RISK"
                recovery_required = True
            elif sig < -68 or lat > 65 or loss > 3:
                prob = round(35 + abs(sig + 68) * 0.8 + (lat - 65) * 0.2)
                status = "WARNING"
                recovery_required = False
            else:
                prob = max(8, round(15 - (abs(sig) - 45) * 0.1))
                status = "GOOD"
                recovery_required = False

            self._send_json(200, {
                "failureProbability": prob / 100.0,
                "failureProbabilityPercent": prob,
                "status": status,
                "recoveryRequired": recovery_required,
                "explanation": f"Evaluated RF signal {sig} dBm, latency {lat} ms, loss {loss}%"
            })

        elif path == '/network/metrics':
            # Ingests metrics from device
            print(f"[LinkPulse API] Telemetry metrics received: {body}")
            self._send_json(200, {"status": "recorded", "received": body})

        elif path == '/recovery/evaluate':
            current_net = body.get('currentNetwork', 'Wi-Fi')
            current_metrics = body.get('currentMetrics', {})
            candidates = body.get('candidates', [])

            current_score = calculate_score(current_metrics)
            best_cand = None
            best_cand_score = -1

            for c in candidates:
                s = calculate_score(c)
                c['score'] = s
                if s > best_cand_score:
                    best_cand_score = s
                    best_cand = c

            switch_rec = (best_cand is not None and (best_cand_score - current_score >= 15))

            self._send_json(200, {
                "currentNetwork": current_net,
                "currentScore": current_score,
                "bestCandidate": best_cand.get('network_type', '5G') if best_cand else None,
                "candidateScore": best_cand_score if best_cand else current_score,
                "improvement": (best_cand_score - current_score) if best_cand else 0,
                "switchRecommended": switch_rec,
                "reason": f"Evaluated {len(candidates)} alternative networks. Score improvement: {best_cand_score - current_score} pts."
            })

        elif path == '/recovery/event':
            # Saves recovery audit event
            body['id'] = len(RECOVERY_HISTORY) + 1
            if 'timestamp' not in body:
                body['timestamp'] = datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            RECOVERY_HISTORY.insert(0, body)
            if len(RECOVERY_HISTORY) > 50:
                RECOVERY_HISTORY.pop()

            print(f"[LinkPulse API] Recovery event recorded: {body.get('previousNetwork')} -> {body.get('newNetwork')} ({body.get('result')})")
            self._send_json(201, {"status": "created", "event": body})

        else:
            self._send_json(404, {"error": "Endpoint not found"})


def run_server():
    server = HTTPServer((HOST, PORT), LinkPulseRequestHandler)
    print(f"==================================================")
    print(f"LinkPulse REST API Server active on http://{HOST}:{PORT}")
    print(f"Endpoints: /predict, /network/metrics, /recovery/evaluate, /recovery/event, /recovery/history")
    print(f"==================================================")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down LinkPulse API server...")
        server.server_close()


if __name__ == '__main__':
    run_server()
