/**
 * LinkPulse - Network Monitoring Module (Multi-Transport & Dataset Integrated)
 * Observes Wi-Fi, 4G, 5G telemetry, measures RTT latency & RF attenuation,
 * and provides interactive viva simulation controls with KNN inference.
 */

// History log array
let telemetryHistory = [];

/**
 * Initializes the Network Monitor Page
 */
document.addEventListener('DOMContentLoaded', () => {
  // Load current shared state
  const state = getNetworkState();
  renderMonitorPage(state);

  // Initialize event listeners
  setupMonitorControls();

  // Listen for native online/offline state changes
  setupConnectivityListeners((updatedState) => {
    renderMonitorPage(updatedState);
    logTelemetryEvent('Browser Event', updatedState, 'Browser connectivity state changed');
  });

  // If Dataset is ready, re-evaluate initial state
  if (window.LinkPulseData && window.LinkPulseData.isLoaded()) {
    updateStateAndEvaluate(state);
  }
  window.addEventListener('linkpulse:data-loaded', () => {
    updateStateAndEvaluate(getNetworkState());
  });

  // Initial log entry
  logTelemetryEvent('Initial Baseline', state, `Active transport: ${state.connectionType || 'Wi-Fi'}`);
});

/**
 * Attaches event handlers to UI buttons and controls
 */
function setupMonitorControls() {
  const checkBtn = document.getElementById('btn-check-network');
  const analyzeBtn = document.getElementById('btn-analyze-current');
  const typeSelect = document.getElementById('select-network-type');
  
  // Presets
  const presetStableWifi = document.getElementById('preset-stable-wifi');
  const presetFast5G = document.getElementById('preset-fast-5g');
  const presetFading4G = document.getElementById('preset-fading-4g');
  const presetCriticalWifi = document.getElementById('preset-critical-wifi');
  const presetOffline = document.getElementById('preset-offline');

  // Sliders
  const sliderSignal = document.getElementById('slider-signal');
  const sliderLatency = document.getElementById('slider-latency');

  if (checkBtn) {
    checkBtn.addEventListener('click', () => {
      runNetworkCheck();
    });
  }

  if (analyzeBtn) {
    analyzeBtn.addEventListener('click', () => {
      runPredictionAnalysis();
    });
  }

  if (typeSelect) {
    typeSelect.addEventListener('change', (e) => {
      const state = getNetworkState();
      state.connectionType = e.target.value;
      updateStateAndEvaluate(state);
      logTelemetryEvent('Transport Changed', state, `Selected ${state.connectionType}`);
    });
  }

  // Preset 1: Stable Wi-Fi
  if (presetStableWifi) {
    presetStableWifi.addEventListener('click', () => {
      applySimulationPreset({
        isOnline: true,
        connectionType: 'Wi-Fi',
        signalDbm: -54,
        latencyMs: 22,
        packetLossPercent: 0.5,
        jitterMs: 4,
        downloadMbps: 45.0,
        uploadMbps: 14.0,
        networkLoad: 25
      }, 'Applied Preset: Stable Wi-Fi (Low Risk)');
    });
  }

  // Preset 2: Ultra-Fast 5G
  if (presetFast5G) {
    presetFast5G.addEventListener('click', () => {
      applySimulationPreset({
        isOnline: true,
        connectionType: '5G',
        signalDbm: -48,
        latencyMs: 16,
        packetLossPercent: 0.2,
        jitterMs: 3,
        downloadMbps: 90.0,
        uploadMbps: 25.0,
        networkLoad: 20
      }, 'Applied Preset: Ultra-Fast 5G (Optimal)');
    });
  }

  // Preset 3: Degraded 4G
  if (presetFading4G) {
    presetFading4G.addEventListener('click', () => {
      applySimulationPreset({
        isOnline: true,
        connectionType: '4G',
        signalDbm: -76,
        latencyMs: 78,
        packetLossPercent: 3.5,
        jitterMs: 12,
        downloadMbps: 15.0,
        uploadMbps: 4.0,
        networkLoad: 65
      }, 'Applied Preset: Degraded 4G (Warning / Moderate Risk)');
    });
  }

  // Preset 4: Critical Wi-Fi Cell Edge
  if (presetCriticalWifi) {
    presetCriticalWifi.addEventListener('click', () => {
      applySimulationPreset({
        isOnline: true,
        connectionType: 'Wi-Fi',
        signalDbm: -88,
        latencyMs: 220,
        packetLossPercent: 26.0,
        jitterMs: 25,
        downloadMbps: 2.0,
        uploadMbps: 0.5,
        networkLoad: 88
      }, 'Applied Preset: Critical Wi-Fi Cell Edge (High Risk)');
    });
  }

  // Preset 5: Disconnected
  if (presetOffline) {
    presetOffline.addEventListener('click', () => {
      applySimulationPreset({
        isOnline: false,
        connectionType: 'None',
        signalDbm: -115,
        latencyMs: 999,
        packetLossPercent: 100.0,
        jitterMs: 0,
        downloadMbps: 0.0,
        uploadMbps: 0.0,
        networkLoad: 0
      }, 'Applied Preset: Link Disconnection (Offline)');
    });
  }

  // Manual Sliders
  if (sliderSignal) {
    sliderSignal.addEventListener('input', (e) => {
      const val = parseInt(e.target.value, 10);
      const label = document.getElementById('slider-signal-val');
      if (label) label.textContent = `${val} dBm`;

      const state = getNetworkState();
      state.signalDbm = val;
      state.isOnline = true;
      updateStateAndEvaluate(state);
    });
  }

  if (sliderLatency) {
    sliderLatency.addEventListener('input', (e) => {
      const val = parseInt(e.target.value, 10);
      const label = document.getElementById('slider-latency-val');
      if (label) label.textContent = `${val} ms`;

      const state = getNetworkState();
      state.latencyMs = val;
      state.isOnline = true;
      updateStateAndEvaluate(state);
    });
  }
}

/**
 * Runs a simulated network check telemetry probe
 */
function runNetworkCheck() {
  const checkBtn = document.getElementById('btn-check-network');
  const originalText = checkBtn ? checkBtn.innerHTML : '';

  if (checkBtn) {
    checkBtn.disabled = true;
    checkBtn.innerHTML = `
      <span class="spin-icon">⏳</span> Probing Interface &amp; Carrier...
    `;
  }

  setTimeout(() => {
    const state = getNetworkState();
    const isOnline = navigator.onLine;
    state.isOnline = isOnline;

    if (!isOnline) {
      state.signalDbm = -115;
      state.latencyMs = 999;
      state.packetLossPercent = 100.0;
      state.connectionType = 'None';
      state.downloadMbps = 0.0;
      state.uploadMbps = 0.0;
    } else {
      // Natural RF telemetry jitter
      const signalJitter = Math.floor(Math.random() * 7) - 3;
      const latencyJitter = Math.floor(Math.random() * 15) - 7;
      state.signalDbm = Math.min(-45, Math.max(-105, state.signalDbm + signalJitter));
      state.latencyMs = Math.max(15, Math.min(230, state.latencyMs + latencyJitter));
      state.jitterMs = Math.max(2, Math.min(30, Math.round(state.latencyMs * 0.12 + (Math.random() * 4 - 2))));
      state.packetLossPercent = calculatePacketLoss(state.signalDbm, state.latencyMs, true);
    }

    updateStateAndEvaluate(state);
    logTelemetryEvent('Manual Check', state, 'User executed Check Network telemetry probe');

    if (checkBtn) {
      checkBtn.disabled = false;
      checkBtn.innerHTML = originalText;
    }
  }, 650);
}

/**
 * Applies a selected preset configuration
 */
function applySimulationPreset(presetData, note) {
  const state = getNetworkState();
  Object.assign(state, presetData);
  updateStateAndEvaluate(state);
  logTelemetryEvent('Preset Changed', state, note);

  // Synchronize controls
  const sliderSignal = document.getElementById('slider-signal');
  const sliderLatency = document.getElementById('slider-latency');
  const labelSignal = document.getElementById('slider-signal-val');
  const labelLatency = document.getElementById('slider-latency-val');
  const typeSelect = document.getElementById('select-network-type');

  if (sliderSignal && labelSignal) {
    sliderSignal.value = state.signalDbm;
    labelSignal.textContent = state.isOnline ? `${state.signalDbm} dBm` : 'N/A (Offline)';
  }
  if (sliderLatency && labelLatency) {
    sliderLatency.value = Math.min(250, state.latencyMs);
    labelLatency.textContent = state.isOnline ? `${state.latencyMs} ms` : 'Infinity (Offline)';
  }
  if (typeSelect && state.connectionType) {
    typeSelect.value = state.connectionType;
  }
}

/**
 * Runs dataset-based KNN prediction and displays detailed assessment
 */
function runPredictionAnalysis() {
  const state = getNetworkState();
  const box = document.getElementById('mon-prediction-box');
  const badge = document.getElementById('mon-pred-badge');
  const probText = document.getElementById('mon-pred-prob-text');
  const explText = document.getElementById('mon-pred-explanation');
  const recActionRow = document.getElementById('mon-rec-action-row');

  let knn = null;
  if (window.LinkPulseData && typeof window.LinkPulseData.predictNetworkRisk === 'function') {
    knn = window.LinkPulseData.predictNetworkRisk({
      signal_strength: state.signalDbm,
      latency: state.latencyMs,
      packet_loss: state.packetLossPercent,
      jitter: state.jitterMs || 5,
      download_speed: state.downloadMbps || 25,
      upload_speed: state.uploadMbps || 8,
      network_load: state.networkLoad || 35,
      network_type: state.connectionType || 'Wi-Fi'
    }, 7);
  } else {
    // Fallback evaluation
    const evalRes = evaluateNetworkPrediction(state.signalDbm, state.latencyMs, state.isOnline);
    knn = {
      predictedRisk: evalRes.riskLevel,
      networkCondition: evalRes.networkCondition,
      failureProbability: evalRes.failureProbability,
      explanation: evalRes.reason
    };
  }

  state.riskLevel = knn.predictedRisk;
  state.networkCondition = knn.networkCondition;
  state.failureProbability = knn.failureProbability;
  state.predictionReason = knn.explanation;
  state.prediction = knn.predictedRisk === 'High' ? 'HIGH RISK' : knn.predictedRisk === 'Medium' ? 'WARNING' : 'STABLE';
  saveNetworkState(state);
  renderMonitorPage(state);

  if (box) {
    box.style.display = 'block';
    if (badge) {
      badge.className = `badge ${state.riskLevel === 'High' ? 'badge-danger' : state.riskLevel === 'Medium' ? 'badge-warning' : 'badge-stable'}`;
      badge.textContent = state.prediction;
    }
    if (probText) {
      probText.innerHTML = `Failure Probability: <span style="color: ${state.riskLevel === 'High' ? '#dc2626' : state.riskLevel === 'Medium' ? '#d97706' : '#059669'}">${state.failureProbability}%</span>`;
    }
    if (explText) {
      explText.textContent = knn.explanation;
    }
    if (recActionRow) {
      recActionRow.style.display = state.failureProbability >= 70 ? 'block' : 'none';
    }
  }

  logTelemetryEvent('Prediction Check', state, `KNN Predicted: ${state.prediction} (${state.failureProbability}% failure probability)`);
}

/**
 * Evaluates rules, saves state, and re-renders monitor UI
 */
function updateStateAndEvaluate(state) {
  state.packetLossPercent = calculatePacketLoss(state.signalDbm, state.latencyMs, state.isOnline);

  let knn = null;
  if (window.LinkPulseData && typeof window.LinkPulseData.predictNetworkRisk === 'function') {
    knn = window.LinkPulseData.predictNetworkRisk({
      signal_strength: state.signalDbm,
      latency: state.latencyMs,
      packet_loss: state.packetLossPercent,
      jitter: state.jitterMs || 5,
      download_speed: state.downloadMbps || 25,
      upload_speed: state.uploadMbps || 8,
      network_load: state.networkLoad || 35,
      network_type: state.connectionType || 'Wi-Fi'
    }, 7);

    state.prediction = knn.predictedRisk === 'High' ? 'HIGH RISK' : knn.predictedRisk === 'Medium' ? 'WARNING' : 'STABLE';
    state.riskLevel = knn.predictedRisk;
    state.failureProbability = knn.failureProbability;
    state.networkCondition = knn.networkCondition;
    state.predictionReason = knn.explanation;
  } else {
    const evalResult = evaluateNetworkPrediction(state.signalDbm, state.latencyMs, state.isOnline);
    state.prediction = evalResult.prediction;
    state.riskLevel = evalResult.riskLevel;
    state.failureProbability = evalResult.failureProbability;
    state.networkCondition = evalResult.networkCondition;
    state.predictionReason = evalResult.reason;
  }

  state.lastChecked = new Date().toLocaleTimeString();
  saveNetworkState(state);
  renderMonitorPage(state);
}

/**
 * Updates all DOM elements on monitor.html (8 Cards & Status)
 */
function renderMonitorPage(state) {
  const statusEl = document.getElementById('mon-status');
  const typeEl = document.getElementById('mon-type');
  const signalEl = document.getElementById('mon-signal');
  const latencyEl = document.getElementById('mon-latency');
  const lossEl = document.getElementById('mon-loss');
  const jitterEl = document.getElementById('mon-jitter');
  const downEl = document.getElementById('mon-down');
  const upEl = document.getElementById('mon-up');
  const failProbEl = document.getElementById('mon-failprob');
  const riskBadgeEl = document.getElementById('mon-risk-badge');
  const qualityDescEl = document.getElementById('mon-quality-desc');
  const signalBarsContainer = document.getElementById('mon-signal-bars');
  const lastUpdatedEl = document.getElementById('mon-last-updated');

  // 1. Connection Type
  if (typeEl) {
    typeEl.textContent = state.connectionType || 'Wi-Fi';
  }

  // 2. Connection State
  if (statusEl) {
    if (state.isOnline) {
      statusEl.innerHTML = `<span class="badge badge-stable"><span class="badge-dot"></span> Online</span>`;
    } else {
      statusEl.innerHTML = `<span class="badge badge-danger"><span class="badge-dot"></span> Offline</span>`;
    }
  }

  // 3. Signal Strength
  if (signalEl) {
    signalEl.innerHTML = state.isOnline ? `${state.signalDbm} <span class="card-unit">dBm</span>` : `N/A <span class="card-unit">(0 dBm)</span>`;
  }

  // Update signal bars
  if (signalBarsContainer) {
    let activeBars = 4;
    let barColor = 'green';

    if (!state.isOnline || state.signalDbm < -95) {
      activeBars = 0;
    } else if (state.signalDbm < -85) {
      activeBars = 1;
      barColor = 'danger';
    } else if (state.signalDbm < -75) {
      activeBars = 2;
      barColor = 'warning';
    } else if (state.signalDbm < -65) {
      activeBars = 3;
      barColor = 'green';
    } else {
      activeBars = 4;
      barColor = 'green';
    }

    signalBarsContainer.innerHTML = `
      <span class="signal-bar ${activeBars >= 1 ? 'active ' + barColor : ''}"></span>
      <span class="signal-bar ${activeBars >= 2 ? 'active ' + barColor : ''}"></span>
      <span class="signal-bar ${activeBars >= 3 ? 'active ' + barColor : ''}"></span>
      <span class="signal-bar ${activeBars >= 4 ? 'active ' + barColor : ''}"></span>
    `;
  }

  // 4. Latency
  if (latencyEl) {
    latencyEl.innerHTML = state.isOnline ? `${state.latencyMs} <span class="card-unit">ms</span>` : `&infin; <span class="card-unit">ms</span>`;
  }

  // 5. Packet Loss
  if (lossEl) {
    lossEl.innerHTML = `${state.packetLossPercent || calculatePacketLoss(state.signalDbm, state.latencyMs, state.isOnline)} <span class="card-unit">%</span>`;
  }

  // 6. Jitter
  if (jitterEl) {
    jitterEl.innerHTML = `${state.jitterMs || 5} <span class="card-unit">ms</span>`;
  }

  // 7. Download & Upload Speed
  if (downEl) downEl.textContent = (state.downloadMbps || 25.0).toFixed(1);
  if (upEl) upEl.textContent = (state.uploadMbps || 8.0).toFixed(1);

  // 8. Failure Probability & Risk
  if (failProbEl) {
    failProbEl.textContent = `${state.failureProbability || 14}%`;
    failProbEl.style.color = state.riskLevel === 'High' ? 'var(--status-danger)' : state.riskLevel === 'Medium' ? 'var(--status-warning)' : 'var(--status-stable)';
  }
  if (riskBadgeEl) {
    const riskClass = state.riskLevel === 'High' ? 'badge-danger' : state.riskLevel === 'Medium' ? 'badge-warning' : 'badge-stable';
    riskBadgeEl.className = `badge ${riskClass}`;
    riskBadgeEl.textContent = `${state.riskLevel || 'Low'} Risk`;
  }
  if (qualityDescEl) {
    qualityDescEl.textContent = state.isOnline 
      ? (state.riskLevel === 'High' ? 'High failure risk: Recovery recommended' : state.riskLevel === 'Medium' ? 'Warning: Degradation detected' : 'Link is nominal & stable')
      : 'Network socket offline';
  }

  if (lastUpdatedEl) {
    lastUpdatedEl.textContent = `Last sampled: ${state.lastChecked || new Date().toLocaleTimeString()}`;
  }
}

/**
 * Appends an entry to the telemetry event log table
 */
function logTelemetryEvent(eventType, state, notes) {
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  telemetryHistory.unshift({
    timestamp,
    eventType,
    status: state.isOnline ? 'Online' : 'Offline',
    signal: `${state.signalDbm} dBm`,
    latency: `${state.latencyMs} ms`,
    type: state.connectionType || 'Wi-Fi',
    notes
  });

  if (telemetryHistory.length > 7) {
    telemetryHistory.pop();
  }

  renderTelemetryTable();
}

/**
 * Renders the telemetry log table rows
 */
function renderTelemetryTable() {
  const tbody = document.getElementById('telemetry-log-body');
  if (!tbody) return;

  if (telemetryHistory.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-muted);">No telemetry logged yet.</td></tr>`;
    return;
  }

  tbody.innerHTML = telemetryHistory.map((entry) => `
    <tr>
      <td style="font-family: monospace; font-weight: 600;">${entry.timestamp}</td>
      <td><span class="badge ${entry.status === 'Online' ? 'badge-stable' : 'badge-danger'}">${entry.status}</span></td>
      <td><strong>${entry.type}</strong></td>
      <td>${entry.signal}</td>
      <td>${entry.latency}</td>
      <td style="font-size: 0.82rem; color: var(--text-muted);">${entry.notes}</td>
    </tr>
  `).join('');
}
