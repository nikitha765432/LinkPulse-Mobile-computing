/**
 * LinkPulse - Predictive Failure Detection Module (Dataset & KNN Powered)
 * Interacts with LinkPulseData to run client-side KNN inference on synthetic telemetry records.
 */

document.addEventListener('DOMContentLoaded', () => {
  // Sync with current shared network state
  const state = getNetworkState();
  initPredictionInputs(state);

  // If dataset is already loaded, populate dataset stats & run initial prediction
  if (window.LinkPulseData && window.LinkPulseData.isLoaded()) {
    renderDatasetStats(window.LinkPulseData.getStats());
    executePredictionAnalysis();
  }

  // Listen for dataset load event
  window.addEventListener('linkpulse:data-loaded', (e) => {
    renderDatasetStats(e.detail);
    executePredictionAnalysis();
  });

  // Attach control listeners
  setupPredictionControls();
});

/**
 * Initializes slider and input elements with active state
 */
function initPredictionInputs(state) {
  setInputValue('input-signal', state.signalDbm || -62, 'val-signal', ' dBm');
  setInputValue('input-latency', state.latencyMs || 42, 'val-latency', ' ms');
  setInputValue('input-loss', state.packetLossPercent || 1.2, 'val-loss', '%');
  setInputValue('input-jitter', state.jitterMs || 5, 'val-jitter', ' ms');
  setInputValue('input-download', state.downloadMbps || 25, 'val-download', ' Mbps');
  setInputValue('input-upload', state.uploadMbps || 8, 'val-upload', ' Mbps');
  setInputValue('input-load', state.networkLoad || 35, 'val-load', '%');

  const typeEl = document.getElementById('input-type');
  if (typeEl && state.connectionType) {
    typeEl.value = state.connectionType;
  }
}

function setInputValue(id, val, labelId, unit) {
  const el = document.getElementById(id);
  const lbl = document.getElementById(labelId);
  if (el) el.value = val;
  if (lbl) lbl.textContent = `${val}${unit}`;
}

/**
 * Attaches event listeners to inputs and action buttons
 */
function setupPredictionControls() {
  const inputs = [
    { id: 'input-signal', label: 'val-signal', unit: ' dBm' },
    { id: 'input-latency', label: 'val-latency', unit: ' ms' },
    { id: 'input-loss', label: 'val-loss', unit: '%' },
    { id: 'input-jitter', label: 'val-jitter', unit: ' ms' },
    { id: 'input-download', label: 'val-download', unit: ' Mbps' },
    { id: 'input-upload', label: 'val-upload', unit: ' Mbps' },
    { id: 'input-load', label: 'val-load', unit: '%' }
  ];

  inputs.forEach((item) => {
    const el = document.getElementById(item.id);
    const lbl = document.getElementById(item.label);
    if (el) {
      el.addEventListener('input', (e) => {
        if (lbl) lbl.textContent = `${e.target.value}${item.unit}`;
      });
    }
  });

  const btnAnalyze = document.getElementById('btn-analyze-network');
  if (btnAnalyze) {
    btnAnalyze.addEventListener('click', () => {
      executePredictionAnalysis();
    });
  }

  // Preset buttons
  const btnPresetStable = document.getElementById('btn-preset-stable');
  const btnPresetWarning = document.getElementById('btn-preset-warning');
  const btnPresetHigh = document.getElementById('btn-preset-high');

  if (btnPresetStable) {
    btnPresetStable.addEventListener('click', () => {
      applyPreset({
        signal: -52,
        latency: 28,
        loss: 0.4,
        jitter: 3,
        download: 55,
        upload: 15,
        load: 25,
        type: '5G'
      });
    });
  }

  if (btnPresetWarning) {
    btnPresetWarning.addEventListener('click', () => {
      applyPreset({
        signal: -72,
        latency: 78,
        loss: 3.2,
        jitter: 14,
        download: 14,
        upload: 4,
        load: 68,
        type: '4G'
      });
    });
  }

  if (btnPresetHigh) {
    btnPresetHigh.addEventListener('click', () => {
      applyPreset({
        signal: -94,
        latency: 165,
        loss: 11.5,
        jitter: 34,
        download: 1.8,
        upload: 0.5,
        load: 92,
        type: '3G'
      });
    });
  }
}

function applyPreset(p) {
  setInputValue('input-signal', p.signal, 'val-signal', ' dBm');
  setInputValue('input-latency', p.latency, 'val-latency', ' ms');
  setInputValue('input-loss', p.loss, 'val-loss', '%');
  setInputValue('input-jitter', p.jitter, 'val-jitter', ' ms');
  setInputValue('input-download', p.download, 'val-download', ' Mbps');
  setInputValue('input-upload', p.upload, 'val-upload', ' Mbps');
  setInputValue('input-load', p.load, 'val-load', '%');
  const typeEl = document.getElementById('input-type');
  if (typeEl) typeEl.value = p.type;

  executePredictionAnalysis();
}

/**
 * Executes KNN classification using LinkPulseData engine
 */
function executePredictionAnalysis() {
  const btn = document.getElementById('btn-analyze-network');
  const origText = btn ? btn.innerHTML : '';
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = `<span class="spin-icon">⚙️</span> Running KNN Classification...`;
  }

  setTimeout(() => {
    const inputVec = {
      signal_strength: parseFloat(document.getElementById('input-signal')?.value || -62),
      latency: parseFloat(document.getElementById('input-latency')?.value || 42),
      packet_loss: parseFloat(document.getElementById('input-loss')?.value || 1.2),
      jitter: parseFloat(document.getElementById('input-jitter')?.value || 5),
      download_speed: parseFloat(document.getElementById('input-download')?.value || 25),
      upload_speed: parseFloat(document.getElementById('input-upload')?.value || 8),
      network_load: parseFloat(document.getElementById('input-load')?.value || 35),
      network_type: document.getElementById('input-type')?.value || '4G'
    };

    let result;
    if (window.LinkPulseData && typeof window.LinkPulseData.predictNetworkRisk === 'function') {
      result = window.LinkPulseData.predictNetworkRisk(inputVec, 7);
    } else {
      result = {
        predictedRisk: 'Low',
        networkCondition: 'Healthy',
        failureProbability: 15,
        confidence: 90,
        nearestNeighbors: [],
        explanation: 'Baseline heuristic classification.'
      };
    }

    renderPredictionOutputs(result, inputVec);

    // Save to shared localStorage so recovery.html immediately uses this prediction!
    const state = getNetworkState();
    state.signalDbm = inputVec.signal_strength;
    state.latencyMs = inputVec.latency;
    state.packetLossPercent = inputVec.packet_loss;
    state.jitterMs = inputVec.jitter;
    state.downloadMbps = inputVec.download_speed;
    state.uploadMbps = inputVec.upload_speed;
    state.networkLoad = inputVec.network_load;
    state.connectionType = inputVec.network_type;
    state.riskLevel = result.predictedRisk;
    state.networkCondition = result.networkCondition;
    state.failureProbability = result.failureProbability;
    state.confidence = result.confidence;
    state.prediction = result.predictedRisk === 'High' ? 'HIGH RISK' : result.predictedRisk === 'Medium' ? 'WARNING' : 'STABLE';
    state.predictionReason = result.explanation;
    state.lastChecked = new Date().toLocaleTimeString();

    saveNetworkState(state);

    if (btn) {
      btn.disabled = false;
      btn.innerHTML = origText;
    }
  }, 400);
}

/**
 * Updates UI with prediction metrics & nearest neighbors
 */
function renderPredictionOutputs(result, inputVec) {
  const elRiskLevel = document.getElementById('res-risk-level');
  const elFailProb = document.getElementById('res-failure-prob');
  const elCond = document.getElementById('res-condition');
  const elConf = document.getElementById('res-confidence');
  const elExp = document.getElementById('res-explanation');
  const elProbBar = document.getElementById('res-prob-bar');
  const neighborsBody = document.getElementById('nearest-neighbors-body');

  let riskBadge = 'badge-stable';
  if (result.predictedRisk === 'High') riskBadge = 'badge-danger';
  else if (result.predictedRisk === 'Medium') riskBadge = 'badge-warning';

  if (elRiskLevel) {
    elRiskLevel.className = `badge ${riskBadge}`;
    elRiskLevel.innerHTML = `<span class="badge-dot"></span> ${result.predictedRisk.toUpperCase()} RISK`;
    elRiskLevel.style.fontSize = '1.15rem';
    elRiskLevel.style.padding = '8px 18px';
  }

  if (elFailProb) elFailProb.textContent = `${result.failureProbability}%`;
  if (elCond) {
    let condBadge = 'badge-stable';
    if (result.networkCondition === 'Critical') condBadge = 'badge-danger';
    else if (result.networkCondition === 'Degraded') condBadge = 'badge-warning';
    elCond.className = `badge ${condBadge}`;
    elCond.innerHTML = `<span class="badge-dot"></span> ${result.networkCondition}`;
  }
  if (elConf) elConf.textContent = `${result.confidence}%`;
  if (elExp) elExp.textContent = result.explanation;

  if (elProbBar) {
    elProbBar.style.width = `${result.failureProbability}%`;
    if (result.failureProbability < 35) {
      elProbBar.style.background = 'linear-gradient(90deg, #10b981, #38bdf8)';
    } else if (result.failureProbability < 70) {
      elProbBar.style.background = 'linear-gradient(90deg, #f59e0b, #fbbf24)';
    } else {
      elProbBar.style.background = 'linear-gradient(90deg, #ef4444, #f87171)';
    }
  }

  // Render top 5 nearest neighbors table
  if (neighborsBody && result.nearestNeighbors) {
    if (result.nearestNeighbors.length === 0) {
      neighborsBody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--text-muted); padding: 16px;">Dataset neighbors available when CSV is loaded.</td></tr>`;
      return;
    }

    neighborsBody.innerHTML = result.nearestNeighbors.map((n, idx) => {
      const badge = n.risk === 'High' ? 'badge-danger' : n.risk === 'Medium' ? 'badge-warning' : 'badge-stable';
      return `
        <tr>
          <td><strong>#${idx + 1}</strong></td>
          <td style="font-family: monospace;">d = ${n.distance.toFixed(3)}</td>
          <td>${n.signal} dBm</td>
          <td>${n.latency} ms</td>
          <td>${n.loss}%</td>
          <td><span class="badge ${badge}"><span class="badge-dot"></span> ${n.risk}</span></td>
        </tr>
      `;
    }).join('');
  }
}

/**
 * Renders dataset analysis & preprocessing status cards dynamically from CSV
 */
function renderDatasetStats(stats) {
  if (!stats) return;

  // Dataset Status (Section 4)
  const elLoaded = document.getElementById('ds-records-loaded');
  const elValid = document.getElementById('ds-valid-records');
  const elMissing = document.getElementById('ds-missing-values');
  const elFeatures = document.getElementById('ds-features-count');

  if (elLoaded) elLoaded.textContent = stats.totalRecords;
  if (elValid) elValid.textContent = stats.validRecords;
  if (elMissing) elMissing.textContent = stats.missingValues;
  if (elFeatures) elFeatures.textContent = stats.featuresCount;

  // Dataset Analysis (Section 3)
  const elTotal = document.getElementById('ds-total-records');
  const elStable = document.getElementById('ds-stable-records');
  const elDegraded = document.getElementById('ds-degraded-records');
  const elHighRisk = document.getElementById('ds-highrisk-records');

  if (elTotal) elTotal.textContent = stats.validRecords;
  if (elStable) elStable.textContent = stats.stableCount;
  if (elDegraded) elDegraded.textContent = stats.degradedCount;
  if (elHighRisk) elHighRisk.textContent = stats.highRiskCount;
}
