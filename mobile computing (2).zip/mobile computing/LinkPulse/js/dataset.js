/**
 * LinkPulse - Dataset Preprocessing & Machine Learning Inference Engine
 * Implements CSV loading, data cleaning, feature standardization,
 * and a client-side K-Nearest Neighbors (KNN) classifier.
 *
 * Dataset: Synthetic Network Monitoring Dataset for Academic Demonstration
 */

(function (window) {
  'use strict';

  // Dataset State Store
  const DatasetStore = {
    isLoaded: false,
    rawRecords: [],
    validRecords: [],
    missingCount: 0,
    featuresList: [
      'signal_strength',
      'latency',
      'packet_loss',
      'jitter',
      'download_speed',
      'upload_speed',
      'network_load',
      'network_type'
    ],
    stats: {
      totalRecords: 0,
      validRecords: 0,
      missingValues: 0,
      featuresCount: 8,
      stableCount: 0,
      degradedCount: 0,
      highRiskCount: 0,
      avgSignal: 0,
      avgLatency: 0,
      avgPacketLoss: 0,
      avgJitter: 0,
      avgDownload: 0,
      avgUpload: 0,
      networkTypeDistribution: { '5G': 0, '4G': 0, '3G': 0, 'Wi-Fi': 0 },
      riskDistribution: { 'Low': 0, 'Medium': 0, 'High': 0 }
    },
    featureNorms: {}, // mean and std dev for feature scaling
    callbacks: []
  };

  // Network type numerical encoder
  function encodeNetworkType(typeStr) {
    if (!typeStr) return 2;
    const t = String(typeStr).toUpperCase().trim();
    if (t.includes('5G')) return 3;
    if (t.includes('4G') || t.includes('LTE')) return 2;
    if (t.includes('WI-FI') || t.includes('WIFI')) return 2.2;
    if (t.includes('3G')) return 1;
    return 2;
  }

  /**
   * Parses CSV string into structured telemetry records
   */
  function parseCSV(csvText) {
    const lines = csvText.trim().split(/\r?\n/);
    if (lines.length < 2) return [];

    const headers = lines[0].split(',').map((h) => h.trim().toLowerCase());
    const records = [];
    let missingFound = 0;

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      const cols = line.split(',');
      if (cols.length < headers.length) {
        missingFound++;
        continue;
      }

      const row = {};
      let hasMissing = false;

      for (let j = 0; j < headers.length; j++) {
        const val = cols[j] ? cols[j].trim() : '';
        if (val === '') {
          hasMissing = true;
          break;
        }
        row[headers[j]] = val;
      }

      if (hasMissing) {
        missingFound++;
        continue;
      }

      // Type conversions
      const record = {
        signal_strength: parseFloat(row.signal_strength),
        latency: parseFloat(row.latency),
        packet_loss: parseFloat(row.packet_loss),
        jitter: parseFloat(row.jitter),
        download_speed: parseFloat(row.download_speed),
        upload_speed: parseFloat(row.upload_speed),
        network_type: row.network_type || '4G',
        network_type_encoded: encodeNetworkType(row.network_type),
        network_load: parseFloat(row.network_load),
        connection_status: row.connection_status || 'Stable',
        failure_risk: row.failure_risk || 'Low'
      };

      // Sanity checks
      if (
        isNaN(record.signal_strength) ||
        isNaN(record.latency) ||
        isNaN(record.packet_loss) ||
        isNaN(record.download_speed)
      ) {
        missingFound++;
        continue;
      }

      records.push(record);
    }

    DatasetStore.missingCount = missingFound;
    return records;
  }

  /**
   * Preprocesses dataset, computes standard deviations and global metrics
   */
  function preprocessDataset(records) {
    DatasetStore.rawRecords = records;
    DatasetStore.validRecords = records;

    const count = records.length;
    if (count === 0) return;

    // Feature aggregations
    let sumSignal = 0;
    let sumLatency = 0;
    let sumLoss = 0;
    let sumJitter = 0;
    let sumDown = 0;
    let sumUp = 0;
    let sumLoad = 0;

    const riskCounts = { Low: 0, Medium: 0, High: 0 };
    const typeCounts = { '5G': 0, '4G': 0, '3G': 0, 'Wi-Fi': 0 };

    records.forEach((r) => {
      sumSignal += r.signal_strength;
      sumLatency += r.latency;
      sumLoss += r.packet_loss;
      sumJitter += r.jitter;
      sumDown += r.download_speed;
      sumUp += r.upload_speed;
      sumLoad += r.network_load;

      // Risk Distribution
      const risk = r.failure_risk || 'Low';
      if (riskCounts[risk] !== undefined) riskCounts[risk]++;
      else riskCounts[risk] = 1;

      // Type Distribution
      const type = r.network_type || '4G';
      if (typeCounts[type] !== undefined) typeCounts[type]++;
      else typeCounts[type] = 1;
    });

    const meanSignal = sumSignal / count;
    const meanLatency = sumLatency / count;
    const meanLoss = sumLoss / count;
    const meanJitter = sumJitter / count;
    const meanDown = sumDown / count;
    const meanUp = sumUp / count;
    const meanLoad = sumLoad / count;

    // Compute variance & standard deviation
    let varSignal = 0;
    let varLatency = 0;
    let varLoss = 0;
    let varJitter = 0;
    let varDown = 0;
    let varLoad = 0;

    records.forEach((r) => {
      varSignal += Math.pow(r.signal_strength - meanSignal, 2);
      varLatency += Math.pow(r.latency - meanLatency, 2);
      varLoss += Math.pow(r.packet_loss - meanLoss, 2);
      varJitter += Math.pow(r.jitter - meanJitter, 2);
      varDown += Math.pow(r.download_speed - meanDown, 2);
      varLoad += Math.pow(r.network_load - meanLoad, 2);
    });

    DatasetStore.featureNorms = {
      signal_strength: { mean: meanSignal, std: Math.sqrt(varSignal / count) || 1 },
      latency: { mean: meanLatency, std: Math.sqrt(varLatency / count) || 1 },
      packet_loss: { mean: meanLoss, std: Math.sqrt(varLoss / count) || 1 },
      jitter: { mean: meanJitter, std: Math.sqrt(varJitter / count) || 1 },
      download_speed: { mean: meanDown, std: Math.sqrt(varDown / count) || 1 },
      network_load: { mean: meanLoad, std: Math.sqrt(varLoad / count) || 1 },
      network_type: { mean: 2.0, std: 0.8 }
    };

    // Store statistics
    DatasetStore.stats = {
      totalRecords: count + DatasetStore.missingCount,
      validRecords: count,
      missingValues: DatasetStore.missingCount,
      featuresCount: DatasetStore.featuresList.length,
      stableCount: riskCounts['Low'] || 0,
      degradedCount: riskCounts['Medium'] || 0,
      highRiskCount: riskCounts['High'] || 0,
      avgSignal: +(meanSignal).toFixed(1),
      avgLatency: +(meanLatency).toFixed(1),
      avgPacketLoss: +(meanLoss).toFixed(1),
      avgJitter: +(meanJitter).toFixed(1),
      avgDownload: +(meanDown).toFixed(1),
      avgUpload: +(meanUp / count).toFixed(1),
      networkTypeDistribution: typeCounts,
      riskDistribution: riskCounts
    };

    DatasetStore.isLoaded = true;

    // Dispatch global custom event for UI updates
    const evt = new CustomEvent('linkpulse:data-loaded', { detail: DatasetStore.stats });
    window.dispatchEvent(evt);
  }

  /**
   * K-Nearest Neighbors (KNN) Inference Engine
   * Evaluates input vector against dataset records with weighted Euclidean distance.
   */
  function predictNetworkRisk(inputFeatures, k = 7) {
    if (!DatasetStore.isLoaded || DatasetStore.validRecords.length === 0) {
      console.warn('Dataset not yet loaded, using rule fallback.');
      return fallbackRulePrediction(inputFeatures);
    }

    // Default input vector with fallback
    const sample = {
      signal_strength: typeof inputFeatures.signal_strength === 'number' ? inputFeatures.signal_strength : -62,
      latency: typeof inputFeatures.latency === 'number' ? inputFeatures.latency : 42,
      packet_loss: typeof inputFeatures.packet_loss === 'number' ? inputFeatures.packet_loss : 1.2,
      jitter: typeof inputFeatures.jitter === 'number' ? inputFeatures.jitter : 5,
      download_speed: typeof inputFeatures.download_speed === 'number' ? inputFeatures.download_speed : 25,
      network_load: typeof inputFeatures.network_load === 'number' ? inputFeatures.network_load : 35,
      network_type_encoded: encodeNetworkType(inputFeatures.network_type || '4G')
    };

    const norms = DatasetStore.featureNorms;

    // Feature importance weights
    const weights = {
      signal_strength: 2.0,
      latency: 2.2,
      packet_loss: 2.4,
      jitter: 1.2,
      download_speed: 1.0,
      network_load: 1.4,
      network_type: 0.6
    };

    // Calculate distance to each record
    const neighbors = [];
    for (let i = 0; i < DatasetStore.validRecords.length; i++) {
      const rec = DatasetStore.validRecords[i];

      // Standardized Euclidean distance
      const dSig = ((sample.signal_strength - rec.signal_strength) / norms.signal_strength.std) * weights.signal_strength;
      const dLat = ((sample.latency - rec.latency) / norms.latency.std) * weights.latency;
      const dLoss = ((sample.packet_loss - rec.packet_loss) / norms.packet_loss.std) * weights.packet_loss;
      const dJit = ((sample.jitter - rec.jitter) / norms.jitter.std) * weights.jitter;
      const dDown = ((sample.download_speed - rec.download_speed) / norms.download_speed.std) * weights.download_speed;
      const dLoad = ((sample.network_load - rec.network_load) / norms.network_load.std) * weights.network_load;
      const dType = ((sample.network_type_encoded - rec.network_type_encoded) / norms.network_type.std) * weights.network_type;

      const distSq = dSig * dSig + dLat * dLat + dLoss * dLoss + dJit * dJit + dDown * dDown + dLoad * dLoad + dType * dType;
      const dist = Math.sqrt(distSq);

      neighbors.push({
        distance: dist,
        risk: rec.failure_risk,
        status: rec.connection_status,
        signal: rec.signal_strength,
        latency: rec.latency,
        loss: rec.packet_loss
      });
    }

    // Sort ascending by distance and pick top K
    neighbors.sort((a, b) => a.distance - b.distance);
    const topK = neighbors.slice(0, k);

    // Vote tallies
    const votes = { Low: 0, Medium: 0, High: 0 };
    let highRiskWeight = 0;
    let medRiskWeight = 0;

    topK.forEach((n) => {
      votes[n.risk] = (votes[n.risk] || 0) + 1;
      // Inverse distance weighting
      const w = 1 / (n.distance + 0.1);
      if (n.risk === 'High') highRiskWeight += w;
      if (n.risk === 'Medium') medRiskWeight += w;
    });

    // Winning class
    let predictedRisk = 'Low';
    if (votes.High >= votes.Medium && votes.High >= votes.Low) {
      predictedRisk = 'High';
    } else if (votes.Medium >= votes.Low) {
      predictedRisk = 'Medium';
    } else {
      predictedRisk = 'Low';
    }

    // Failure probability calculation
    const highRatio = votes.High / k;
    const medRatio = votes.Medium / k;
    let failureProbability = Math.round(highRatio * 100 + medRatio * 40);
    failureProbability = Math.max(5, Math.min(98, failureProbability));

    // Confidence is vote agreement of top class
    const maxVotes = Math.max(votes.Low, votes.Medium, votes.High);
    const confidence = Math.round((maxVotes / k) * 100);

    // Network condition mapping
    let networkCondition = 'Healthy';
    if (predictedRisk === 'High') networkCondition = 'Critical';
    else if (predictedRisk === 'Medium') networkCondition = 'Degraded';
    else networkCondition = 'Healthy';

    return {
      predictedRisk,
      networkCondition,
      failureProbability,
      confidence,
      votes,
      k,
      nearestNeighbors: topK.slice(0, 5),
      explanation: `KNN classifier ($K=${k}$) identified ${maxVotes}/${k} nearest historical telemetry vectors corresponding to ${predictedRisk} Risk condition.`
    };
  }

  /**
   * Fallback heuristic if dataset is still loading
   */
  function fallbackRulePrediction(input) {
    const sig = input.signal_strength || -62;
    const lat = input.latency || 42;
    if (sig < -80 || lat > 100) {
      return {
        predictedRisk: 'High',
        networkCondition: 'Critical',
        failureProbability: 84,
        confidence: 88,
        nearestNeighbors: [],
        explanation: 'Heuristic model fallback: Elevated latency or severe RF attenuation detected.'
      };
    }
    if (sig < -65 || lat > 50) {
      return {
        predictedRisk: 'Medium',
        networkCondition: 'Degraded',
        failureProbability: 48,
        confidence: 76,
        nearestNeighbors: [],
        explanation: 'Heuristic model fallback: Moderate latency jitter or fading RF signal detected.'
      };
    }
    return {
      predictedRisk: 'Low',
      networkCondition: 'Healthy',
      failureProbability: 12,
      confidence: 94,
      nearestNeighbors: [],
      explanation: 'Heuristic model fallback: Signal and latency parameters nominal.'
    };
  }

  // =========================================================================
  // SMART RECOVERY & MULTI-TRANSPORT NETWORK QUALITY SCORER (Section 7, 11, 12)
  // =========================================================================
  const CONFIG = {
    HIGH_RISK_THRESHOLD: 0.70,     // Failure probability >= 70% triggers recovery
    RECOVERY_COOLDOWN_MS: 30000,   // 30 seconds anti-ping-pong cooldown
    MIN_NETWORK_IMPROVEMENT: 15,   // Candidate must score at least 15 points higher
    RECOVERY_TIMEOUT_MS: 10000,    // 10 seconds verification timeout
    WEIGHTS: {
      signal: 0.30,
      latency: 0.25,
      packet_loss: 0.20,
      download: 0.15,
      stability: 0.10
    }
  };

  /**
   * Calculates a multi-attribute Network Quality Score (0 to 100)
   * Formula:
   *   Score = 0.30 * SignalScore + 0.25 * LatencyScore + 0.20 * LossScore
   *         + 0.15 * DownloadScore + 0.10 * StabilityScore
   */
  function calculateNetworkScore(metrics) {
    if (!metrics) return 0;

    // 1. Signal score: [-110 dBm (0 pts) to -40 dBm (100 pts)]
    const sig = typeof metrics.signal_strength === 'number' ? metrics.signal_strength : -70;
    let sigScore = ((sig - (-110)) / (-40 - (-110))) * 100;
    sigScore = Math.max(0, Math.min(100, sigScore));

    // 2. Latency score: [250 ms (0 pts) down to 10 ms (100 pts)]
    const lat = typeof metrics.latency === 'number' ? metrics.latency : 50;
    let latScore = ((250 - lat) / (250 - 10)) * 100;
    latScore = Math.max(0, Math.min(100, latScore));

    // 3. Packet loss score: [25% loss (0 pts) down to 0% (100 pts)]
    const loss = typeof metrics.packet_loss === 'number' ? metrics.packet_loss : 1.5;
    let lossScore = ((25 - loss) / 25) * 100;
    lossScore = Math.max(0, Math.min(100, lossScore));

    // 4. Download speed score: [0 Mbps (0 pts) to 100 Mbps (100 pts)]
    const down = typeof metrics.download_speed === 'number' ? metrics.download_speed : 25;
    let downScore = (down / 100) * 100;
    downScore = Math.max(0, Math.min(100, downScore));

    // 5. Stability score: derived from jitter (0-30ms) & failure probability (0-100%)
    const jitter = typeof metrics.jitter === 'number' ? metrics.jitter : 5;
    const failProb = typeof metrics.failure_probability === 'number' ? metrics.failure_probability : 20;
    const jitterScore = Math.max(0, Math.min(100, ((30 - jitter) / 30) * 100));
    const failScore = Math.max(0, Math.min(100, 100 - failProb));
    const stabilityScore = jitterScore * 0.5 + failScore * 0.5;

    // Weighted composite
    const total = (
      CONFIG.WEIGHTS.signal * sigScore +
      CONFIG.WEIGHTS.latency * latScore +
      CONFIG.WEIGHTS.packet_loss * lossScore +
      CONFIG.WEIGHTS.download * downScore +
      CONFIG.WEIGHTS.stability * stabilityScore
    );

    return Math.round(Math.max(5, Math.min(100, total)));
  }

  /**
   * Evaluates available candidate networks against current network conditions.
   * Enforces Cooldown (30s) and Minimum Improvement (15 pts).
   */
  function evaluateCandidates(currentNetwork, currentMetrics, candidateList, lastRecoveryTime = 0) {
    const currentScore = calculateNetworkScore(currentMetrics);
    const now = Date.now();
    const timeSinceLast = now - lastRecoveryTime;
    const isCooldownActive = timeSinceLast < CONFIG.RECOVERY_COOLDOWN_MS;
    const cooldownRemainingSec = isCooldownActive ? Math.ceil((CONFIG.RECOVERY_COOLDOWN_MS - timeSinceLast) / 1000) : 0;

    const evaluatedCandidates = (candidateList || []).map((cand) => {
      const candScore = calculateNetworkScore(cand);
      const improvement = candScore - currentScore;
      const isViable = candScore > currentScore && improvement >= CONFIG.MIN_NETWORK_IMPROVEMENT;

      return {
        ...cand,
        score: candScore,
        improvement,
        isViable
      };
    });

    // Sort by highest score descending
    evaluatedCandidates.sort((a, b) => b.score - a.score);

    const bestCandidate = evaluatedCandidates.length > 0 ? evaluatedCandidates[0] : null;

    let switchRecommended = false;
    let decisionReason = '';

    if (!bestCandidate) {
      decisionReason = 'No candidate networks discovered.';
    } else if (isCooldownActive) {
      decisionReason = `Recovery cooldown active (${cooldownRemainingSec}s remaining). Preventing ping-pong switching.`;
    } else if (bestCandidate.improvement < CONFIG.MIN_NETWORK_IMPROVEMENT) {
      decisionReason = `Best alternative (${bestCandidate.network_type}) score ${bestCandidate.score} does not exceed minimum improvement threshold (+${CONFIG.MIN_NETWORK_IMPROVEMENT} pts required, actual: +${bestCandidate.improvement} pts).`;
    } else {
      switchRecommended = true;
      decisionReason = `Switching from ${currentNetwork} (Score ${currentScore}) to ${bestCandidate.network_type} (Score ${bestCandidate.score}) offers significant connectivity improvement (+${bestCandidate.improvement}%).`;
    }

    return {
      currentNetwork,
      currentScore,
      bestCandidate,
      candidates: evaluatedCandidates,
      switchRecommended,
      isCooldownActive,
      cooldownRemainingSec,
      decisionReason
    };
  }

  /**
   * Loads dataset via fetch from 'data/network_data.csv'
   */
  function loadDataset(url = 'data/network_data.csv') {
    return fetch(url)
      .then((res) => {
        if (!res.ok) {
          throw new Error(`Failed to load dataset: HTTP ${res.status}`);
        }
        return res.text();
      })
      .then((csvText) => {
        const records = parseCSV(csvText);
        preprocessDataset(records);
        return DatasetStore.stats;
      })
      .catch((err) => {
        console.warn('Dataset fetch failed, attempting relative fallback:', err);
        // Try relative to current script path
        return fetch('../data/network_data.csv')
          .then((r) => r.text())
          .then((txt) => {
            const records = parseCSV(txt);
            preprocessDataset(records);
            return DatasetStore.stats;
          })
          .catch((e2) => {
            console.error('All dataset fetch attempts failed:', e2);
          });
      });
  }

  // Auto-load dataset on DOM load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => loadDataset());
  } else {
    loadDataset();
  }

  // Export to global namespace
  window.LinkPulseData = {
    loadDataset,
    predictNetworkRisk,
    calculateNetworkScore,
    evaluateCandidates,
    CONFIG,
    getStore: () => DatasetStore,
    getStats: () => DatasetStore.stats,
    isLoaded: () => DatasetStore.isLoaded
  };

})(window);
