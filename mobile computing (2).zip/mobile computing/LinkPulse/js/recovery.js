/**
 * LinkPulse - Smart Recovery Dashboard Module (Multi-Transport & Dataset Integrated)
 * Implements predictive failure detection, multi-attribute network quality scoring,
 * alternative candidate evaluation (Wi-Fi, 4G, 5G), anti-ping-pong protection (30s cooldown, +15 pt threshold),
 * reverse recovery, connectivity verification, and audited recovery history.
 */

const HISTORY_STORAGE_KEY = 'linkpulse_recovery_history_v2';
let isRecoveryRunning = false;
let liveMonitorInterval = null;
let lastRecoveryTimestamp = 0;

// Seed history records matching Section 18 format
const SEED_HISTORY = [
  {
    id: 1,
    timestamp: '23-11-2026 12:35:10',
    previousNetwork: 'Wi-Fi',
    newNetwork: '5G',
    reason: 'High packet loss & RF attenuation (86% fail prob)',
    failureProbability: 86,
    oldScore: 38,
    newScore: 89,
    recoveryTime: '1.8s',
    result: 'SUCCESS',
    resultBadge: 'badge-stable'
  },
  {
    id: 2,
    timestamp: '23-11-2026 12:20:45',
    previousNetwork: '5G',
    newNetwork: 'Wi-Fi',
    reason: 'Reverse Recovery: 5G congestion, 5GHz Wi-Fi superior',
    failureProbability: 74,
    oldScore: 45,
    newScore: 84,
    recoveryTime: '1.9s',
    result: 'SUCCESS',
    resultBadge: 'badge-stable'
  },
  {
    id: 3,
    timestamp: '23-11-2026 12:05:12',
    previousNetwork: '4G',
    newNetwork: 'None',
    reason: 'Alternative candidate improvement (+6 pts) below +15 pt threshold',
    failureProbability: 52,
    oldScore: 58,
    newScore: 64,
    recoveryTime: '-',
    result: 'NO_SWITCH',
    resultBadge: 'badge-warning'
  }
];

// Discovered Candidate Networks Catalog
let availableCandidates = [
  {
    network_type: '5G',
    signal_strength: -48,
    latency: 16,
    packet_loss: 0.2,
    jitter: 3,
    download_speed: 90.0,
    upload_speed: 25.0,
    stability: 95
  },
  {
    network_type: '4G',
    signal_strength: -68,
    latency: 52,
    packet_loss: 1.8,
    jitter: 9,
    download_speed: 28.0,
    upload_speed: 7.0,
    stability: 80
  },
  {
    network_type: 'Wi-Fi',
    signal_strength: -55,
    latency: 22,
    packet_loss: 0.6,
    jitter: 4,
    download_speed: 55.0,
    upload_speed: 15.0,
    stability: 90
  }
];

document.addEventListener('DOMContentLoaded', () => {
  initLiveClock();

  // Load state and render initial UI
  const state = getNetworkState();
  renderRecoveryDashboard(state);
  renderRecoveryHistoryTable();

  // If Dataset ML Engine is ready, render dataset stats & charts
  if (window.LinkPulseData && window.LinkPulseData.isLoaded()) {
    onDatasetReady(window.LinkPulseData.getStats());
  }

  // Listen for dataset load event
  window.addEventListener('linkpulse:data-loaded', (e) => {
    onDatasetReady(e.detail);
  });

  // Setup buttons, controls & Section 24 test scenarios
  setupRecoveryControls();
  setupTestScenarios();

  // Live background monitoring tick (every 5 seconds)
  startLiveMonitoring();

  // Listen for real browser connectivity changes
  setupConnectivityListeners((updatedState) => {
    renderRecoveryDashboard(updatedState);
  });

  // Responsive redraw for charts
  window.addEventListener('resize', () => {
    if (window.LinkPulseData && window.LinkPulseData.isLoaded()) {
      drawDatasetTrendChart();
      drawDistributionChart();
    }
  });
});

/**
 * Triggered when dataset finishes parsing
 */
function onDatasetReady(stats) {
  renderDatasetDashboardStats(stats);
  drawDatasetTrendChart();
  drawDistributionChart();

  const state = getNetworkState();
  updateStateEvaluationWithModel(state);
}

/**
 * Updates state using KNN prediction and updates candidate network scoring
 */
function updateStateEvaluationWithModel(state) {
  if (window.LinkPulseData && typeof window.LinkPulseData.predictNetworkRisk === 'function') {
    const knn = window.LinkPulseData.predictNetworkRisk({
      signal_strength: state.signalDbm,
      latency: state.latencyMs,
      packet_loss: state.packetLossPercent,
      jitter: state.jitterMs || 5,
      download_speed: state.downloadMbps || 25,
      upload_speed: state.uploadMbps || 8,
      network_load: state.networkLoad || 35,
      network_type: state.connectionType || 'Wi-Fi'
    }, 7);

    state.riskLevel = knn.predictedRisk;
    state.networkCondition = knn.networkCondition;
    state.failureProbability = knn.failureProbability;
    state.confidence = knn.confidence;
    state.prediction = knn.predictedRisk === 'High' ? 'HIGH RISK' : knn.predictedRisk === 'Medium' ? 'WARNING' : 'STABLE';
    state.predictionReason = knn.explanation;

    saveNetworkState(state);
    renderRecoveryDashboard(state);
  }
}

/**
 * Live Clock and Date Updater
 */
function initLiveClock() {
  function updateTime() {
    const now = new Date();
    const timeEl = document.getElementById('live-clock-time');
    const dateEl = document.getElementById('live-clock-date');
    if (timeEl) {
      timeEl.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }
    if (dateEl) {
      dateEl.textContent = now.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
    }
  }
  updateTime();
  setInterval(updateTime, 1000);
}

/**
 * Attach button & interactive listeners
 */
function setupRecoveryControls() {
  const btnStart = document.getElementById('btn-start-recovery');
  const btnRecheck = document.getElementById('btn-recheck-network');
  const btnRetry = document.getElementById('btn-retry-connection');
  const btnSettings = document.getElementById('btn-open-settings');
  const btnRefresh = document.getElementById('btn-refresh-status');
  const btnClearHistory = document.getElementById('btn-clear-history');
  const toggleLive = document.getElementById('toggle-live-monitor');

  // Network Settings modal triggers
  const netSettingsModal = document.getElementById('network-settings-modal');
  const closeNetModal = document.querySelectorAll('[data-close-net-modal]');

  if (btnStart) {
    btnStart.addEventListener('click', () => {
      if (!isRecoveryRunning) {
        startSmartRecoveryPipeline();
      }
    });
  }

  if (btnRecheck) {
    btnRecheck.addEventListener('click', () => {
      performNetworkRecheck();
    });
  }

  if (btnRetry) {
    btnRetry.addEventListener('click', () => {
      performConnectionRetry();
    });
  }

  if (btnSettings && netSettingsModal) {
    btnSettings.addEventListener('click', () => {
      netSettingsModal.classList.add('active');
      document.body.style.overflow = 'hidden';
    });
  }

  closeNetModal.forEach((el) => {
    el.addEventListener('click', () => {
      if (netSettingsModal) {
        netSettingsModal.classList.remove('active');
        document.body.style.overflow = '';
      }
    });
  });

  if (btnRefresh) {
    btnRefresh.addEventListener('click', () => {
      performNetworkRecheck(true);
    });
  }

  if (btnClearHistory) {
    btnClearHistory.addEventListener('click', () => {
      if (confirm('Clear all recorded recovery activity history?')) {
        localStorage.removeItem(HISTORY_STORAGE_KEY);
        renderRecoveryHistoryTable();
      }
    });
  }

  if (toggleLive) {
    toggleLive.addEventListener('change', (e) => {
      if (e.target.checked) startLiveMonitoring();
      else stopLiveMonitoring();
    });
  }
}

/**
 * Section 24: Test Recovery Scenarios Implementation
 */
function setupTestScenarios() {
  const t1 = document.getElementById('btn-test-1');
  const t2 = document.getElementById('btn-test-2');
  const t3 = document.getElementById('btn-test-3');
  const t4 = document.getElementById('btn-test-4');
  const t5 = document.getElementById('btn-test-5');
  const t6 = document.getElementById('btn-test-6');
  const t7 = document.getElementById('btn-test-7');
  const t8 = document.getElementById('btn-test-8');

  // TEST 1: Stable Wi-Fi (No recovery triggered)
  if (t1) {
    t1.addEventListener('click', () => {
      setActiveTestButton(t1);
      const state = getNetworkState();
      state.isOnline = true;
      state.connectionType = 'Wi-Fi';
      state.signalDbm = -52;
      state.latencyMs = 24;
      state.packetLossPercent = 0.4;
      state.jitterMs = 3;
      state.downloadMbps = 50.0;
      state.uploadMbps = 15.0;
      updateStateEvaluationWithModel(state);
      alert('TEST 1: Stable Wi-Fi loaded. Prediction: STABLE (Failure Prob ~12%). No recovery required.');
    });
  }

  // TEST 2: High Latency Wi-Fi (Warning condition)
  if (t2) {
    t2.addEventListener('click', () => {
      setActiveTestButton(t2);
      const state = getNetworkState();
      state.isOnline = true;
      state.connectionType = 'Wi-Fi';
      state.signalDbm = -72;
      state.latencyMs = 125;
      state.packetLossPercent = 4.2;
      state.jitterMs = 18;
      state.downloadMbps = 14.0;
      state.uploadMbps = 3.5;
      updateStateEvaluationWithModel(state);
      alert('TEST 2: Wi-Fi High Latency (125ms) loaded. Prediction: WARNING (Moderate Risk). Monitoring active.');
    });
  }

  // TEST 3: Wi-Fi Severe Degradation -> Switch to 5G (Recovered)
  if (t3) {
    t3.addEventListener('click', () => {
      setActiveTestButton(t3);
      const state = getNetworkState();
      state.isOnline = true;
      state.connectionType = 'Wi-Fi';
      state.signalDbm = -88;
      state.latencyMs = 230;
      state.packetLossPercent = 27.0;
      state.jitterMs = 28;
      state.downloadMbps = 1.8;
      state.uploadMbps = 0.4;
      updateStateEvaluationWithModel(state);

      // Set candidates where 5G is best
      availableCandidates = [
        { network_type: '5G', signal_strength: -48, latency: 16, packet_loss: 0.2, jitter: 3, download_speed: 90, upload_speed: 25 },
        { network_type: '4G', signal_strength: -68, latency: 50, packet_loss: 2.1, jitter: 8, download_speed: 25, upload_speed: 6 }
      ];

      alert('TEST 3: Severe Wi-Fi degradation loaded (Failure Prob ~86%). Starting automated Smart Recovery to 5G...');
      startSmartRecoveryPipeline();
    });
  }

  // TEST 4: 5G Degraded -> Reverse Recovery to Wi-Fi
  if (t4) {
    t4.addEventListener('click', () => {
      setActiveTestButton(t4);
      const state = getNetworkState();
      state.isOnline = true;
      state.connectionType = '5G';
      state.signalDbm = -94;
      state.latencyMs = 195;
      state.packetLossPercent = 22.0;
      state.jitterMs = 24;
      state.downloadMbps = 3.2;
      state.uploadMbps = 0.8;
      updateStateEvaluationWithModel(state);

      // Set candidates where Wi-Fi is superior
      availableCandidates = [
        { network_type: 'Wi-Fi', signal_strength: -52, latency: 20, packet_loss: 0.5, jitter: 4, download_speed: 60, upload_speed: 18 },
        { network_type: '4G', signal_strength: -74, latency: 68, packet_loss: 3.2, jitter: 12, download_speed: 16, upload_speed: 4 }
      ];

      alert('TEST 4: Reverse Recovery loaded: 5G congested (-94 dBm), local 5GHz Wi-Fi is strong (-52 dBm). Starting Recovery to Wi-Fi...');
      startSmartRecoveryPipeline();
    });
  }

  // TEST 5: Current Network Poor + No Alternative Available
  if (t5) {
    t5.addEventListener('click', () => {
      setActiveTestButton(t5);
      const state = getNetworkState();
      state.isOnline = true;
      state.connectionType = 'Wi-Fi';
      state.signalDbm = -92;
      state.latencyMs = 210;
      state.packetLossPercent = 24.0;
      state.jitterMs = 25;
      updateStateEvaluationWithModel(state);

      // Empty candidates
      availableCandidates = [];
      alert('TEST 5: Poor connection loaded with NO available candidate networks. Smart Recovery will report: RECOVERY FAILED.');
      startSmartRecoveryPipeline(false, true); // force no candidates
    });
  }

  // TEST 6: Alternative Only Slightly Better (+5 pts, No Switch)
  if (t6) {
    t6.addEventListener('click', () => {
      setActiveTestButton(t6);
      const state = getNetworkState();
      state.isOnline = true;
      state.connectionType = '4G';
      state.signalDbm = -70;
      state.latencyMs = 60;
      state.packetLossPercent = 2.0;
      state.jitterMs = 8;
      state.downloadMbps = 20;
      state.uploadMbps = 5;
      updateStateEvaluationWithModel(state);

      // Candidate with only +4 pts improvement
      availableCandidates = [
        { network_type: 'Wi-Fi', signal_strength: -68, latency: 55, packet_loss: 1.8, jitter: 7, download_speed: 22, upload_speed: 6 }
      ];

      alert('TEST 6: Alternative network is only slightly better (+4 pts). Anti-ping-pong rule blocks switch (+15 pts required).');
      startSmartRecoveryPipeline();
    });
  }

  // TEST 7: Network Request Timeout Simulation
  if (t7) {
    t7.addEventListener('click', () => {
      setActiveTestButton(t7);
      const state = getNetworkState();
      state.isOnline = true;
      state.connectionType = 'Wi-Fi';
      state.signalDbm = -90;
      state.latencyMs = 230;
      state.packetLossPercent = 28.0;
      updateStateEvaluationWithModel(state);

      availableCandidates = [
        { network_type: '5G', signal_strength: -50, latency: 18, packet_loss: 0.3, jitter: 3, download_speed: 80, upload_speed: 20 }
      ];

      alert('TEST 7: Simulating radio handshake timeout (RECOVERY_TIMEOUT = 10s). Expected: RECOVERY FAILED (Validation Timeout).');
      startSmartRecoveryPipeline(true); // force timeout
    });
  }

  // TEST 8: Full Success Recovery
  if (t8) {
    t8.addEventListener('click', () => {
      setActiveTestButton(t8);
      const state = getNetworkState();
      state.isOnline = true;
      state.connectionType = 'Wi-Fi';
      state.signalDbm = -86;
      state.latencyMs = 215;
      state.packetLossPercent = 23.0;
      state.jitterMs = 26;
      state.downloadMbps = 2.4;
      updateStateEvaluationWithModel(state);

      availableCandidates = [
        { network_type: '5G', signal_strength: -46, latency: 15, packet_loss: 0.2, jitter: 2, download_speed: 95, upload_speed: 28 },
        { network_type: '4G', signal_strength: -66, latency: 45, packet_loss: 1.5, jitter: 7, download_speed: 30, upload_speed: 8 }
      ];

      startSmartRecoveryPipeline();
    });
  }
}

function setActiveTestButton(btnEl) {
  document.querySelectorAll('.test-btn').forEach((b) => b.classList.remove('active'));
  if (btnEl) btnEl.classList.add('active');
}

/**
 * Live Monitoring Loop
 */
function startLiveMonitoring() {
  if (liveMonitorInterval) clearInterval(liveMonitorInterval);
  const badge = document.getElementById('monitoring-status-text');
  if (badge) badge.textContent = 'System Monitoring Active';

  liveMonitorInterval = setInterval(() => {
    const state = getNetworkState();
    if (state.isOnline && !isRecoveryRunning) {
      const sJitter = Math.floor(Math.random() * 3) - 1;
      const lJitter = Math.floor(Math.random() * 5) - 2;
      state.signalDbm = Math.min(-45, Math.max(-105, state.signalDbm + sJitter));
      state.latencyMs = Math.max(15, Math.min(240, state.latencyMs + lJitter));
      state.packetLossPercent = calculatePacketLoss(state.signalDbm, state.latencyMs, true);

      updateStateEvaluationWithModel(state);
    }
  }, 5000);
}

function stopLiveMonitoring() {
  if (liveMonitorInterval) {
    clearInterval(liveMonitorInterval);
    liveMonitorInterval = null;
  }
  const badge = document.getElementById('monitoring-status-text');
  if (badge) badge.textContent = 'Monitoring Paused';
}

/**
 * Recheck Network Handler
 */
function performNetworkRecheck(isManual = false) {
  const btn = isManual ? document.getElementById('btn-refresh-status') : document.getElementById('btn-recheck-network');
  const origHtml = btn ? btn.innerHTML : '';
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = `<span class="spin-icon">⏳</span> Probing Interface...`;
  }

  setTimeout(() => {
    const state = getNetworkState();
    state.isOnline = navigator.onLine;

    if (state.isOnline) {
      state.signalDbm = Math.min(-46, Math.max(-98, state.signalDbm + (Math.floor(Math.random() * 7) - 3)));
      state.latencyMs = Math.max(18, Math.min(210, state.latencyMs + (Math.floor(Math.random() * 15) - 7)));
      state.packetLossPercent = calculatePacketLoss(state.signalDbm, state.latencyMs, true);
    } else {
      state.signalDbm = -115;
      state.latencyMs = 999;
      state.packetLossPercent = 100.0;
    }

    state.lastChecked = new Date().toLocaleTimeString();
    updateStateEvaluationWithModel(state);

    if (btn) {
      btn.disabled = false;
      btn.innerHTML = origHtml;
    }
  }, 650);
}

/**
 * Retry Connection Handler (Simulates link re-handshake)
 */
function performConnectionRetry() {
  const btn = document.getElementById('btn-retry-connection');
  const origHtml = btn ? btn.innerHTML : '';
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = `<span class="spin-icon">🔄</span> Reconnecting Socket...`;
  }

  setTimeout(() => {
    const state = getNetworkState();
    state.isOnline = true;
    state.signalDbm = Math.max(-56, state.signalDbm + 16);
    state.latencyMs = Math.max(22, Math.round(state.latencyMs * 0.55));
    state.packetLossPercent = calculatePacketLoss(state.signalDbm, state.latencyMs, true);

    updateStateEvaluationWithModel(state);

    addRecoveryHistoryEntry({
      timestamp: formatTimestamp(new Date()),
      previousNetwork: state.connectionType,
      newNetwork: state.connectionType,
      reason: 'Manual link retry & socket renegotiation',
      failureProbability: state.failureProbability,
      oldScore: 45,
      newScore: 82,
      recoveryTime: '1.2s',
      result: 'SUCCESS',
      resultBadge: 'badge-stable'
    });

    if (btn) {
      btn.disabled = false;
      btn.innerHTML = origHtml;
    }
  }, 850);
}

/**
 * 5-Stage Smart Recovery Pipeline Execution (Section 2, 8, 10, 11, 12, 13)
 * Flow: Network Analysis -> Problem Detection -> Risk Assessment -> Recovery Recommendation -> Connection Verification
 */
function startSmartRecoveryPipeline(forceTimeout = false, forceNoCandidates = false) {
  isRecoveryRunning = true;
  const startBtn = document.getElementById('btn-start-recovery');
  const origBtnText = startBtn ? startBtn.innerHTML : '';
  
  if (startBtn) {
    startBtn.disabled = true;
    startBtn.innerHTML = `<span class="spin-icon">⚙️</span> Smart Recovery Running...`;
  }

  const stages = [
    { el: document.getElementById('stage-1'), marker: document.getElementById('term-marker-1'), row: document.getElementById('term-row-1') },
    { el: document.getElementById('stage-2'), marker: document.getElementById('term-marker-2'), row: document.getElementById('term-row-2') },
    { el: document.getElementById('stage-3'), marker: document.getElementById('term-marker-3'), row: document.getElementById('term-row-3') },
    { el: document.getElementById('stage-4'), marker: document.getElementById('term-marker-4'), row: document.getElementById('term-row-4') },
    { el: document.getElementById('stage-5'), marker: document.getElementById('term-marker-5'), row: document.getElementById('term-row-5') }
  ];

  const completionBanner = document.getElementById('recovery-completion-banner');
  if (completionBanner) completionBanner.style.display = 'none';

  // Reset stages
  stages.forEach((st) => {
    if (st.el) {
      st.el.className = 'pipeline-stage';
      const badge = st.el.querySelector('.stage-status-badge');
      if (badge) {
        badge.className = 'stage-status-badge pending';
        badge.textContent = 'Pending';
      }
    }
    if (st.marker) {
      st.marker.className = 'step-marker pending';
      st.marker.textContent = '-';
    }
    if (st.row) st.row.className = 'terminal-step-row';
  });

  const state = getNetworkState();
  const prevNetwork = state.connectionType || 'Wi-Fi';

  // Candidate evaluation
  let currentMetrics = {
    signal_strength: state.signalDbm,
    latency: state.latencyMs,
    packet_loss: state.packetLossPercent,
    jitter: state.jitterMs || 5,
    download_speed: state.downloadMbps || 25,
    upload_speed: state.uploadMbps || 8,
    failure_probability: state.failureProbability || 20
  };

  let evalResult = null;
  if (window.LinkPulseData && typeof window.LinkPulseData.evaluateCandidates === 'function') {
    const listToEval = forceNoCandidates ? [] : availableCandidates.filter((c) => c.network_type !== prevNetwork);
    evalResult = window.LinkPulseData.evaluateCandidates(prevNetwork, currentMetrics, listToEval, lastRecoveryTimestamp);
  }

  // Stage 1: Network Analysis
  setStage(stages[0], 'processing', '●');
  setTimeout(() => {
    setStage(stages[0], 'completed', '✓');
    // Stage 2: Problem Detection
    setStage(stages[1], 'processing', '●');
  }, 500);

  // Stage 2 Complete -> Stage 3: Risk Assessment (KNN model)
  setTimeout(() => {
    setStage(stages[1], 'completed', '✓');
    setStage(stages[2], 'processing', '●');
  }, 1100);

  // Stage 3 Complete -> Stage 4: Recovery Recommendation (Network Selection & Scoring)
  setTimeout(() => {
    setStage(stages[2], 'completed', '✓');
    setStage(stages[3], 'processing', '●');
    renderCandidateEvaluation(evalResult, prevNetwork);
  }, 1800);

  // Stage 4 Complete -> Stage 5: Connection Verification
  setTimeout(() => {
    setStage(stages[3], 'completed', '✓');
    setStage(stages[4], 'processing', '●');

    // Stage 5 Execution: Handshake Verification or Timeout
    const verifyDelay = forceTimeout ? 3000 : 900;
    setTimeout(() => {
      isRecoveryRunning = false;
      if (startBtn) {
        startBtn.disabled = false;
        startBtn.innerHTML = origBtnText;
      }

      // Check Outcome
      if (forceTimeout) {
        setStage(stages[4], 'error', '✗');
        handleRecoveryFailure('Network validation timeout (Exceeded 10s RECOVERY_TIMEOUT limit)', prevNetwork, evalResult);
        return;
      }

      if (forceNoCandidates || !evalResult || !evalResult.bestCandidate) {
        setStage(stages[4], 'error', '✗');
        handleRecoveryFailure('No suitable alternative network available', prevNetwork, evalResult);
        return;
      }

      if (!evalResult.switchRecommended) {
        setStage(stages[4], 'completed', '✓');
        handleNoSwitch(evalResult.decisionReason, prevNetwork, evalResult);
        return;
      }

      // Successful Recovery Switch
      setStage(stages[4], 'completed', '✓');
      handleRecoverySuccess(prevNetwork, evalResult.bestCandidate, evalResult);

    }, verifyDelay);

  }, 2500);
}

function setStage(stageObj, status, markerText) {
  if (stageObj.el) {
    stageObj.el.className = `pipeline-stage ${status === 'processing' ? 'active' : status === 'completed' ? 'completed' : status === 'error' ? 'error' : ''}`;
    const badge = stageObj.el.querySelector('.stage-status-badge');
    if (badge) {
      badge.className = `stage-status-badge ${status}`;
      badge.textContent = status === 'error' ? 'Failed' : status.charAt(0).toUpperCase() + status.slice(1);
    }
  }
  if (stageObj.marker) {
    stageObj.marker.className = `step-marker ${status === 'processing' ? 'active' : status === 'completed' ? 'done' : status === 'error' ? 'error' : 'pending'}`;
    stageObj.marker.textContent = markerText;
  }
  if (stageObj.row) {
    stageObj.row.className = `terminal-step-row ${status === 'processing' ? 'active' : status === 'completed' ? 'done' : status === 'error' ? 'error' : ''}`;
  }
}

/**
 * Handles Successful Network Switch & Verification
 */
function handleRecoverySuccess(prevNetwork, bestCandidate, evalResult) {
  lastRecoveryTimestamp = Date.now();
  const state = getNetworkState();

  // Switch state to selected candidate
  state.connectionType = bestCandidate.network_type;
  state.signalDbm = bestCandidate.signal_strength;
  state.latencyMs = bestCandidate.latency;
  state.packetLossPercent = bestCandidate.packet_loss;
  state.jitterMs = bestCandidate.jitter;
  state.downloadMbps = bestCandidate.download_speed;
  state.uploadMbps = bestCandidate.upload_speed;
  state.isOnline = true;

  updateStateEvaluationWithModel(state);

  const banner = document.getElementById('recovery-completion-banner');
  if (banner) {
    banner.style.display = 'flex';
    banner.style.background = 'rgba(16, 185, 129, 0.15)';
    banner.style.borderColor = 'rgba(16, 185, 129, 0.3)';
    banner.style.color = '#059669';
    banner.innerHTML = `
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
      <div>
        <strong>SMART RECOVERY SUCCESSFUL:</strong> Switched ${prevNetwork} &rarr; ${bestCandidate.network_type} • Verified Nominal Socket Handshake (1.8s) • Quality Score: ${evalResult.currentScore} &rarr; ${bestCandidate.score} (+${bestCandidate.improvement} pts)
      </div>
    `;
  }

  addRecoveryHistoryEntry({
    timestamp: formatTimestamp(new Date()),
    previousNetwork: prevNetwork,
    newNetwork: bestCandidate.network_type,
    reason: `Autonomous switch: ${bestCandidate.network_type} scored ${bestCandidate.score} (+${bestCandidate.improvement} pts higher)`,
    failureProbability: state.failureProbability,
    oldScore: evalResult.currentScore,
    newScore: bestCandidate.score,
    recoveryTime: '1.8s',
    result: 'SUCCESS',
    resultBadge: 'badge-stable'
  });
}

/**
 * Handles Recovery Failure (e.g. timeout, no candidate)
 */
function handleRecoveryFailure(reason, prevNetwork, evalResult) {
  const banner = document.getElementById('recovery-completion-banner');
  if (banner) {
    banner.style.display = 'flex';
    banner.style.background = 'rgba(239, 68, 68, 0.15)';
    banner.style.borderColor = 'rgba(239, 68, 68, 0.3)';
    banner.style.color = '#dc2626';
    banner.innerHTML = `
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
      <div>
        <strong>SMART RECOVERY FAILED:</strong> ${reason}. Maintaining continuous telemetry monitoring.
      </div>
    `;
  }

  addRecoveryHistoryEntry({
    timestamp: formatTimestamp(new Date()),
    previousNetwork: prevNetwork,
    newNetwork: 'None',
    reason,
    failureProbability: getNetworkState().failureProbability,
    oldScore: evalResult ? evalResult.currentScore : 30,
    newScore: evalResult ? evalResult.currentScore : 30,
    recoveryTime: '-',
    result: 'FAILED',
    resultBadge: 'badge-danger'
  });
}

/**
 * Handles No Switch condition (e.g. improvement below threshold or cooldown active)
 */
function handleNoSwitch(reason, prevNetwork, evalResult) {
  const banner = document.getElementById('recovery-completion-banner');
  if (banner) {
    banner.style.display = 'flex';
    banner.style.background = 'rgba(245, 158, 11, 0.15)';
    banner.style.borderColor = 'rgba(245, 158, 11, 0.3)';
    banner.style.color = '#d97706';
    banner.innerHTML = `
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
      <div>
        <strong>SWITCH SUPPRESSED:</strong> ${reason}
      </div>
    `;
  }

  addRecoveryHistoryEntry({
    timestamp: formatTimestamp(new Date()),
    previousNetwork: prevNetwork,
    newNetwork: 'None',
    reason,
    failureProbability: getNetworkState().failureProbability,
    oldScore: evalResult.currentScore,
    newScore: evalResult.bestCandidate ? evalResult.bestCandidate.score : evalResult.currentScore,
    recoveryTime: '-',
    result: 'NO_SWITCH',
    resultBadge: 'badge-warning'
  });
}

/**
 * Renders Candidate Networks Card dynamically
 */
function renderCandidateEvaluation(evalResult, currentNetwork) {
  const rationaleEl = document.getElementById('rec-selection-rationale');
  const candCurrName = document.getElementById('cand-current-name');
  const candCurrScore = document.getElementById('cand-current-score');
  const candCurrMetrics = document.getElementById('cand-current-metrics');

  const state = getNetworkState();

  if (candCurrName) candCurrName.textContent = `${currentNetwork} (Current)`;
  if (candCurrScore) candCurrScore.textContent = evalResult ? evalResult.currentScore : 42;
  if (candCurrMetrics) {
    candCurrMetrics.textContent = `Sig: ${state.signalDbm} dBm • Lat: ${state.latencyMs} ms • Loss: ${state.packetLossPercent}%`;
  }

  if (rationaleEl && evalResult) {
    rationaleEl.innerHTML = `<strong>Decision Rationale:</strong> ${evalResult.decisionReason}`;
  }
}

/**
 * Render all core recovery dashboard elements
 */
function renderRecoveryDashboard(state) {
  // 1. Health Summary Cards (6 Cards)
  const elStatus = document.getElementById('sum-status');
  const elType = document.getElementById('sum-type');
  const elSignal = document.getElementById('sum-signal');
  const elLatency = document.getElementById('sum-latency');
  const elLoss = document.getElementById('sum-packetloss');
  const elRisk = document.getElementById('sum-risk');

  if (elStatus) {
    elStatus.innerHTML = state.isOnline 
      ? `<span class="badge badge-stable"><span class="badge-dot"></span> Connected</span>`
      : `<span class="badge badge-danger"><span class="badge-dot"></span> Disconnected</span>`;
  }
  if (elType) elType.textContent = state.connectionType || 'Wi-Fi';
  if (elSignal) {
    elSignal.innerHTML = state.isOnline ? `${state.signalDbm} <span class="card-unit">dBm</span>` : `N/A <span class="card-unit">(Offline)</span>`;
  }
  if (elLatency) {
    elLatency.innerHTML = state.isOnline ? `${state.latencyMs} <span class="card-unit">ms</span>` : `&infin; <span class="card-unit">ms</span>`;
  }
  if (elLoss) {
    elLoss.innerHTML = `${state.packetLossPercent || calculatePacketLoss(state.signalDbm, state.latencyMs, state.isOnline)} <span class="card-unit">%</span>`;
  }
  if (elRisk) {
    const riskBadge = state.riskLevel === 'High' ? 'badge-danger' : state.riskLevel === 'Medium' ? 'badge-warning' : 'badge-stable';
    elRisk.innerHTML = `<span class="badge ${riskBadge}"><span class="badge-dot"></span> ${state.riskLevel}</span>`;
  }

  // 2. Failure Detection Panel
  const elCondBadge = document.getElementById('panel-condition-badge');
  const elRiskBadge = document.getElementById('panel-risk-badge');
  const elPredText = document.getElementById('panel-prediction-text');
  const elRiskAscii = document.getElementById('panel-risk-ascii');
  const elRiskBar = document.getElementById('panel-risk-bar');

  if (elCondBadge) {
    const condClass = state.riskLevel === 'High' ? 'badge-danger' : state.riskLevel === 'Medium' ? 'badge-warning' : 'badge-stable';
    elCondBadge.className = `badge ${condClass}`;
    elCondBadge.innerHTML = `<span class="badge-dot"></span> ${state.networkCondition || 'Healthy'}`;
  }
  if (elRiskBadge) {
    const riskBadge = state.riskLevel === 'High' ? 'badge-danger' : state.riskLevel === 'Medium' ? 'badge-warning' : 'badge-stable';
    elRiskBadge.className = `badge ${riskBadge}`;
    elRiskBadge.innerHTML = `<span class="badge-dot"></span> ${state.riskLevel} Risk`;
  }
  if (elPredText) {
    elPredText.textContent = state.predictionReason || (state.riskLevel === 'High' ? 'High probability of connectivity failure detected.' : state.riskLevel === 'Medium' ? 'Network degradation detected. Connection may become unstable.' : 'Network link parameters nominal.');
  }

  let asciiBar = 'Low Risk  [██░░░░░░░░]';
  let riskScore = 15;
  if (state.riskLevel === 'High') {
    asciiBar = 'High Risk [████████░░]';
    riskScore = 85;
  } else if (state.riskLevel === 'Medium') {
    asciiBar = 'Med Risk  [██████░░░░]';
    riskScore = 52;
  }
  if (elRiskAscii) elRiskAscii.textContent = asciiBar;
  if (elRiskBar) {
    elRiskBar.style.width = `${riskScore}%`;
    if (riskScore < 35) elRiskBar.style.background = 'linear-gradient(90deg, #10b981, #38bdf8)';
    else if (riskScore < 70) elRiskBar.style.background = 'linear-gradient(90deg, #f59e0b, #fbbf24)';
    else elRiskBar.style.background = 'linear-gradient(90deg, #ef4444, #f87171)';
  }

  // 3. Dynamic Recovery Prescription Card
  const elRecTitle = document.getElementById('rec-card-title');
  const elRecList = document.getElementById('rec-card-list');

  if (elRecTitle) {
    elRecTitle.textContent = state.riskLevel === 'High' 
      ? 'High failure probability detected. Evaluate alternative networks (Wi-Fi, 4G, 5G) and execute Smart Recovery.'
      : state.riskLevel === 'Medium'
      ? 'Network degradation detected. Latency variance and packet loss are elevated.'
      : 'Network connection is stable and nominal. Continuous telemetry sampling active.';
  }

  if (elRecList) {
    elRecList.innerHTML = `
      <li>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
        <span>Active Transport: <strong>${state.connectionType || 'Wi-Fi'}</strong> (RSSI: ${state.signalDbm} dBm, RTT: ${state.latencyMs} ms)</span>
      </li>
      <li>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
        <span>Model Failure Probability: <strong>${state.failureProbability || 14}%</strong> (High risk threshold: 70%)</span>
      </li>
      <li>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
        <span>Autonomous Candidate Scanner: Ready across Wi-Fi, 4G LTE, and 5G NR</span>
      </li>
    `;
  }
}

/**
 * Render Dashboard Statistics Cards (Section 11)
 */
function renderDatasetDashboardStats(stats) {
  if (!stats) return;

  const elRecords = document.getElementById('stat-dataset-records');
  const elStable = document.getElementById('stat-stable-cases');
  const elWarning = document.getElementById('stat-warning-cases');
  const elHighRisk = document.getElementById('stat-highrisk-cases');
  const elAvgLat = document.getElementById('stat-avg-latency');
  const elAvgLoss = document.getElementById('stat-avg-loss');
  const elAvgSig = document.getElementById('stat-avg-signal');

  if (elRecords) elRecords.textContent = stats.validRecords;
  if (elStable) elStable.textContent = stats.stableCount;
  if (elWarning) elWarning.textContent = stats.degradedCount;
  if (elHighRisk) elHighRisk.textContent = stats.highRiskCount;
  if (elAvgLat) elAvgLat.textContent = `${stats.avgLatency} ms`;
  if (elAvgLoss) elAvgLoss.textContent = `${stats.avgPacketLoss}%`;
  if (elAvgSig) elAvgSig.textContent = `${stats.avgSignal} dBm`;
}

/**
 * Recovery History Storage Management (Section 18)
 */
function getRecoveryHistory() {
  try {
    const raw = localStorage.getItem(HISTORY_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('History read error:', e);
  }
  localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(SEED_HISTORY));
  return SEED_HISTORY;
}

function addRecoveryHistoryEntry(entry) {
  const history = getRecoveryHistory();
  const newRow = {
    id: Date.now(),
    timestamp: entry.timestamp || formatTimestamp(new Date()),
    previousNetwork: entry.previousNetwork || 'Wi-Fi',
    newNetwork: entry.newNetwork || '5G',
    reason: entry.reason || 'Network degradation predicted',
    failureProbability: entry.failureProbability || 84,
    oldScore: entry.oldScore || 42,
    newScore: entry.newScore || 88,
    recoveryTime: entry.recoveryTime || '1.8s',
    result: entry.result || 'SUCCESS',
    resultBadge: entry.result === 'SUCCESS' ? 'badge-stable' : entry.result === 'NO_SWITCH' ? 'badge-warning' : 'badge-danger'
  };

  history.unshift(newRow);
  if (history.length > 25) history.pop();

  try {
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(history));
  } catch (e) {
    console.warn('History write error:', e);
  }

  renderRecoveryHistoryTable();
}

/**
 * Render Recovery History Table (Section 18)
 * Table: Timestamp | Previous Network | Target Network | Trigger Reason | Fail Prob | Score Change | Recovery Time | Result
 */
function renderRecoveryHistoryTable() {
  const tbody = document.getElementById('recovery-history-body');
  if (!tbody) return;

  const history = getRecoveryHistory();
  if (history.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: var(--text-muted); padding: 24px;">No recovery history recorded yet.</td></tr>`;
    return;
  }

  tbody.innerHTML = history.map((row) => `
    <tr>
      <td style="font-family: monospace; font-size: 0.82rem; font-weight: 600;">${row.timestamp}</td>
      <td><strong>${row.previousNetwork}</strong></td>
      <td><span style="color: #0284c7; font-weight: 700;">${row.newNetwork}</span></td>
      <td style="font-size: 0.85rem; color: var(--text-muted);">${row.reason}</td>
      <td><span style="font-weight: 700; color: ${row.failureProbability >= 70 ? '#dc2626' : row.failureProbability >= 40 ? '#d97706' : '#059669'}">${row.failureProbability}%</span></td>
      <td style="font-family: monospace; font-weight: 700;">${row.oldScore} &rarr; ${row.newScore}</td>
      <td>${row.recoveryTime}</td>
      <td><span class="badge ${row.resultBadge}"><span class="badge-dot"></span> ${row.result}</span></td>
    </tr>
  `).join('');
}

function formatTimestamp(d) {
  const dd = String(d.getDate()).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const yyyy = d.getFullYear();
  const time = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  return `${dd}-${mm}-${yyyy} ${time}`;
}

/**
 * Network Quality Trend Chart (Section 10)
 */
function drawDatasetTrendChart() {
  const canvas = document.getElementById('dataset-trend-canvas');
  if (!canvas || !window.LinkPulseData || !window.LinkPulseData.isLoaded()) return;

  const records = window.LinkPulseData.getStore().validRecords;
  if (!records || records.length === 0) return;

  const ctx = canvas.getContext('2d');
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;

  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  ctx.scale(dpr, dpr);

  const width = rect.width;
  const height = rect.height;

  ctx.fillStyle = '#0f172a';
  ctx.fillRect(0, 0, width, height);

  const padLeft = 45;
  const padRight = 20;
  const padTop = 20;
  const padBottom = 25;
  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;

  // Grid
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
  ctx.lineWidth = 1;
  ctx.fillStyle = '#64748b';
  ctx.font = '10px ui-monospace, sans-serif';

  for (let i = 0; i <= 4; i++) {
    const y = padTop + (plotH / 4) * i;
    ctx.beginPath();
    ctx.moveTo(padLeft, y);
    ctx.lineTo(width - padRight, y);
    ctx.stroke();
    const pct = 100 - i * 25;
    ctx.fillText(`${pct}%`, 10, y + 3);
  }

  const sampleCount = 25;
  const step = Math.floor(records.length / sampleCount) || 1;
  const sampled = [];
  for (let i = 0; i < records.length && sampled.length < sampleCount; i += step) {
    sampled.push(records[i]);
  }

  const stepX = plotW / (sampled.length - 1);

  // Signal Curve (Cyan)
  ctx.beginPath();
  ctx.strokeStyle = '#0284c7';
  ctx.lineWidth = 2;
  for (let i = 0; i < sampled.length; i++) {
    const x = padLeft + i * stepX;
    const normSig = (sampled[i].signal_strength - (-115)) / (-45 - (-115));
    const y = padTop + plotH * (1 - Math.max(0, Math.min(1, normSig)));
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();

  // Latency Curve (Amber)
  ctx.beginPath();
  ctx.strokeStyle = '#f59e0b';
  ctx.lineWidth = 2;
  for (let i = 0; i < sampled.length; i++) {
    const x = padLeft + i * stepX;
    const normLat = (240 - sampled[i].latency) / (240 - 15);
    const y = padTop + plotH * (1 - Math.max(0, Math.min(1, normLat)));
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();

  // Draw points & x labels
  for (let i = 0; i < sampled.length; i += 4) {
    const x = padLeft + i * stepX;
    ctx.fillStyle = '#64748b';
    ctx.textAlign = 'center';
    ctx.fillText(`Rec #${i * step + 1}`, x, height - 8);
  }
}

/**
 * Distribution Chart (Section 10)
 */
function drawDistributionChart() {
  const canvas = document.getElementById('dataset-dist-canvas');
  if (!canvas || !window.LinkPulseData || !window.LinkPulseData.isLoaded()) return;

  const stats = window.LinkPulseData.getStats();
  const ctx = canvas.getContext('2d');
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;

  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  ctx.scale(dpr, dpr);

  const width = rect.width;
  const height = rect.height;

  ctx.fillStyle = '#0f172a';
  ctx.fillRect(0, 0, width, height);

  const bars = [
    { label: 'Stable', val: stats.stableCount, color: '#10b981' },
    { label: 'Degraded', val: stats.degradedCount, color: '#f59e0b' },
    { label: 'High Risk', val: stats.highRiskCount, color: '#ef4444' },
    { label: '5G', val: stats.networkTypeDistribution['5G'] || 0, color: '#38bdf8' },
    { label: '4G', val: stats.networkTypeDistribution['4G'] || 0, color: '#0284c7' },
    { label: 'Wi-Fi', val: stats.networkTypeDistribution['Wi-Fi'] || 0, color: '#8b5cf6' },
    { label: '3G', val: stats.networkTypeDistribution['3G'] || 0, color: '#64748b' }
  ];

  const padLeft = 40;
  const padRight = 20;
  const padTop = 20;
  const padBottom = 25;
  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;

  const barWidth = Math.floor(plotW / bars.length) - 10;
  const maxVal = Math.max(...bars.map((b) => b.val), 1);

  bars.forEach((bar, idx) => {
    const x = padLeft + idx * (barWidth + 10) + 5;
    const barH = (bar.val / maxVal) * plotH;
    const y = padTop + plotH - barH;

    ctx.fillStyle = bar.color;
    ctx.fillRect(x, y, barWidth, barH);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 10px ui-monospace, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`${bar.val}`, x + barWidth / 2, y - 5);

    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px -apple-system, sans-serif';
    ctx.fillText(bar.label, x + barWidth / 2, height - 8);
  });
}
