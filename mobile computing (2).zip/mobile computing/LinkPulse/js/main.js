/**
 * LinkPulse - Main JavaScript Engine
 * Shared state management, browser API integration, and dashboard controller.
 */

// Global constant keys
const STORAGE_KEY = 'linkpulse_network_state';

// Baseline default state
const DEFAULT_STATE = {
  isOnline: true,
  connectionType: '4G',
  signalDbm: -62,
  latencyMs: 42,
  packetLossPercent: 1.2,
  jitterMs: 5,
  downloadMbps: 25.0,
  uploadMbps: 8.0,
  networkLoad: 35,
  riskLevel: 'Low',       // 'Low', 'Medium', 'High'
  prediction: 'STABLE',   // 'STABLE', 'WARNING', 'HIGH RISK'
  networkCondition: 'Healthy', // 'Healthy', 'Degraded', 'Critical'
  failureProbability: 14,
  confidence: 90,
  predictionReason: 'Dataset model: Signal and latency parameters nominal (Stable condition).',
  lastChecked: new Date().toLocaleTimeString(),
  isSimulated: true
};

/**
 * Calculates estimated packet loss percentage from RF signal and latency jitter
 */
function calculatePacketLoss(signalDbm, latencyMs, isOnline = true) {
  if (!isOnline) return 100.0;
  if (signalDbm >= -65 && latencyMs <= 50) {
    // 0.2% - 1.4%
    return +(0.2 + (latencyMs / 50) * 1.0).toFixed(1);
  }
  if (signalDbm < -80 || latencyMs > 100) {
    // 6.5% - 24.0%
    const penalty = Math.min(22, (Math.abs(signalDbm) - 80) * 0.4 + (latencyMs - 100) * 0.1);
    return +(6.5 + penalty).toFixed(1);
  }
  // 1.8% - 5.5%
  return +(1.8 + ((latencyMs - 50) / 50) * 3.2).toFixed(1);
}

/**
 * Retrieves the current network state from localStorage or initializes with defaults.
 */
function getNetworkState() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      // Synchronize with actual browser online/offline status
      if (typeof navigator.onLine === 'boolean') {
        parsed.isOnline = navigator.onLine;
        if (!navigator.onLine) {
          parsed.riskLevel = 'High';
          parsed.prediction = 'HIGH RISK';
          parsed.predictionReason = 'Device is disconnected from the internet (Browser is Offline).';
          parsed.packetLossPercent = 100.0;
        }
      }
      if (typeof parsed.packetLossPercent === 'undefined') {
        parsed.packetLossPercent = calculatePacketLoss(parsed.signalDbm, parsed.latencyMs, parsed.isOnline);
      }
      return parsed;
    }
  } catch (e) {
    console.warn('Unable to access localStorage, fallback to default state.', e);
  }
  return { ...DEFAULT_STATE, isOnline: navigator.onLine };
}

/**
 * Persists the current state to localStorage.
 */
function saveNetworkState(state) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.warn('Unable to persist state to localStorage.', e);
  }
}

/**
 * Dataset-Based Failure Risk Evaluation (KNN Engine)
 * Evaluates current network metrics against the synthetic dataset records.
 */
function evaluateNetworkPrediction(signalDbm, latencyMs, isOnline = true, extraParams = {}) {
  if (!isOnline) {
    return {
      prediction: 'HIGH RISK',
      riskLevel: 'High',
      networkCondition: 'Critical',
      failureProbability: 100,
      confidence: 100,
      badgeClass: 'badge-danger',
      pulseClass: 'danger',
      reason: 'Network interface is disconnected. Complete connectivity failure detected.'
    };
  }

  // If Dataset ML Engine is ready, use KNN Inference
  if (window.LinkPulseData && typeof window.LinkPulseData.predictNetworkRisk === 'function') {
    const loss = typeof extraParams.packet_loss === 'number' 
      ? extraParams.packet_loss 
      : calculatePacketLoss(signalDbm, latencyMs, true);
    
    const inputVec = {
      signal_strength: signalDbm,
      latency: latencyMs,
      packet_loss: loss,
      jitter: typeof extraParams.jitter === 'number' ? extraParams.jitter : Math.max(2, Math.round(latencyMs * 0.12)),
      download_speed: typeof extraParams.download_speed === 'number' ? extraParams.download_speed : Math.max(1, +(40 - (Math.abs(signalDbm) - 50) * 0.6).toFixed(1)),
      upload_speed: typeof extraParams.upload_speed === 'number' ? extraParams.upload_speed : 8,
      network_load: typeof extraParams.network_load === 'number' ? extraParams.network_load : Math.min(95, Math.round(20 + latencyMs * 0.3)),
      network_type: extraParams.network_type || '4G'
    };

    const knnResult = window.LinkPulseData.predictNetworkRisk(inputVec, 7);
    
    let predLabel = 'STABLE';
    let bClass = 'badge-stable';
    let pClass = '';
    
    if (knnResult.predictedRisk === 'High') {
      predLabel = 'HIGH RISK';
      bClass = 'badge-danger';
      pClass = 'danger';
    } else if (knnResult.predictedRisk === 'Medium') {
      predLabel = 'WARNING';
      bClass = 'badge-warning';
      pClass = 'warning';
    }

    return {
      prediction: predLabel,
      riskLevel: knnResult.predictedRisk,
      networkCondition: knnResult.networkCondition,
      failureProbability: knnResult.failureProbability,
      confidence: knnResult.confidence,
      badgeClass: bClass,
      pulseClass: pClass,
      nearestNeighbors: knnResult.nearestNeighbors,
      reason: knnResult.explanation || `KNN inference identified ${knnResult.confidence}% match with ${predLabel} risk dataset records.`
    };
  }

  // Fallback heuristic if dataset is still initializing
  if (signalDbm >= -65 && latencyMs <= 50) {
    return {
      prediction: 'STABLE',
      riskLevel: 'Low',
      networkCondition: 'Healthy',
      failureProbability: 14,
      confidence: 92,
      badgeClass: 'badge-stable',
      pulseClass: '',
      reason: 'Signal strength is strong and latency is low. Network is stable with no signs of degradation.'
    };
  }

  if (signalDbm < -80 || latencyMs > 100) {
    return {
      prediction: 'HIGH RISK',
      riskLevel: 'High',
      networkCondition: 'Critical',
      failureProbability: 86,
      confidence: 88,
      badgeClass: 'badge-danger',
      pulseClass: 'danger',
      reason: 'Poor signal strength and high latency indicate an increased possibility of connectivity failure.'
    };
  }

  return {
    prediction: 'WARNING',
    riskLevel: 'Medium',
    networkCondition: 'Degraded',
    failureProbability: 52,
    confidence: 80,
    badgeClass: 'badge-warning',
    pulseClass: 'warning',
    reason: 'Network quality is decreasing. Moderate latency or fading signal detected.'
  };
}

/**
 * Computes an overall visual Network Health Score (0 - 100%)
 */
function calculateHealthScore(signalDbm, latencyMs, isOnline) {
  if (!isOnline) return 0;
  
  // Signal score: -40 dBm (100 pts) down to -110 dBm (0 pts)
  let sigScore = ((signalDbm - (-110)) / (-40 - (-110))) * 100;
  sigScore = Math.max(0, Math.min(100, sigScore));

  // Latency score: 10 ms (100 pts) down to 250 ms (0 pts)
  let latScore = ((250 - latencyMs) / (250 - 10)) * 100;
  latScore = Math.max(0, Math.min(100, latScore));

  const totalScore = Math.round((sigScore * 0.5) + (latScore * 0.5));
  return Math.max(5, Math.min(100, totalScore));
}

/**
 * Mobile Navigation Toggle Setup
 */
function setupMobileNavigation() {
  const toggleBtn = document.getElementById('nav-toggle');
  const navMenu = document.getElementById('nav-menu');

  if (toggleBtn && navMenu) {
    toggleBtn.addEventListener('click', () => {
      navMenu.classList.toggle('open');
      const expanded = navMenu.classList.contains('open');
      toggleBtn.setAttribute('aria-expanded', expanded);
    });

    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
      if (!toggleBtn.contains(e.target) && !navMenu.contains(e.target)) {
        navMenu.classList.remove('open');
      }
    });
  }
}

/**
 * Update real browser connectivity listeners
 */
function setupConnectivityListeners(onStatusChangeCallback) {
  window.addEventListener('online', () => {
    const state = getNetworkState();
    state.isOnline = true;
    const evaluation = evaluateNetworkPrediction(state.signalDbm, state.latencyMs, true);
    state.prediction = evaluation.prediction;
    state.riskLevel = evaluation.riskLevel;
    state.predictionReason = evaluation.reason;
    saveNetworkState(state);
    if (typeof onStatusChangeCallback === 'function') {
      onStatusChangeCallback(state);
    }
  });

  window.addEventListener('offline', () => {
    const state = getNetworkState();
    state.isOnline = false;
    const evaluation = evaluateNetworkPrediction(state.signalDbm, state.latencyMs, false);
    state.prediction = evaluation.prediction;
    state.riskLevel = evaluation.riskLevel;
    state.predictionReason = evaluation.reason;
    saveNetworkState(state);
    if (typeof onStatusChangeCallback === 'function') {
      onStatusChangeCallback(state);
    }
  });

  // Check if browser Network Information API is available and safely supported
  if (typeof navigator !== 'undefined' && navigator.connection && typeof navigator.connection.addEventListener === 'function') {
    try {
      navigator.connection.addEventListener('change', () => {
        const state = getNetworkState();
        if (navigator.connection.effectiveType) {
          state.connectionType = navigator.connection.effectiveType.toUpperCase();
        }
        if (navigator.connection.rtt && navigator.connection.rtt > 0) {
          state.latencyMs = navigator.connection.rtt;
        }
        if (navigator.connection.downlink) {
          state.downlinkMbps = navigator.connection.downlink;
        }
        const evalResult = evaluateNetworkPrediction(state.signalDbm, state.latencyMs, state.isOnline);
        state.prediction = evalResult.prediction;
        state.riskLevel = evalResult.riskLevel;
        state.predictionReason = evalResult.reason;
        saveNetworkState(state);
        if (typeof onStatusChangeCallback === 'function') {
          onStatusChangeCallback(state);
        }
      });
    } catch (err) {
      console.warn('Network Information API listener not supported:', err);
    }
  }
}

/**
 * Initializes and renders the Home Dashboard (index.html)
 */
function initHomeDashboard() {
  const state = getNetworkState();
  renderHomeDashboard(state);

  setupConnectivityListeners((updatedState) => {
    renderHomeDashboard(updatedState);
  });
}

/**
 * Renders data into index.html dashboard elements
 */
function renderHomeDashboard(state) {
  const statusEl = document.getElementById('dash-status');
  const typeEl = document.getElementById('dash-type');
  const signalEl = document.getElementById('dash-signal');
  const latencyEl = document.getElementById('dash-latency');
  const riskEl = document.getElementById('dash-risk');
  const healthScoreEl = document.getElementById('dash-health-score');
  const healthBarFillEl = document.getElementById('dash-health-bar-fill');
  const healthStatusEl = document.getElementById('dash-health-status');
  const pulseEl = document.getElementById('dash-pulse-dot');

  const evaluation = evaluateNetworkPrediction(state.signalDbm, state.latencyMs, state.isOnline);
  const healthScore = calculateHealthScore(state.signalDbm, state.latencyMs, state.isOnline);

  // Network Status Card
  if (statusEl) {
    if (state.isOnline) {
      statusEl.innerHTML = `<span class="badge badge-stable"><span class="badge-dot"></span> Connected</span>`;
    } else {
      statusEl.innerHTML = `<span class="badge badge-danger"><span class="badge-dot"></span> Disconnected</span>`;
    }
  }

  // Connection Type Card
  if (typeEl) {
    typeEl.textContent = state.connectionType || '4G';
  }

  // Signal Strength Card
  if (signalEl) {
    signalEl.innerHTML = `${state.signalDbm} <span class="card-unit">dBm</span>`;
  }

  // Latency Card
  if (latencyEl) {
    latencyEl.innerHTML = `${state.latencyMs} <span class="card-unit">ms</span>`;
  }

  // Failure Risk Card
  if (riskEl) {
    riskEl.innerHTML = `<span class="badge ${evaluation.badgeClass}"><span class="badge-dot"></span> ${evaluation.riskLevel} Risk</span>`;
  }

  // Visual Health Indicator
  if (healthScoreEl) {
    healthScoreEl.textContent = `${healthScore}%`;
  }
  if (healthBarFillEl) {
    healthBarFillEl.style.width = `${healthScore}%`;
    if (healthScore > 70) {
      healthBarFillEl.style.background = 'linear-gradient(90deg, #10b981, #38bdf8)';
    } else if (healthScore > 40) {
      healthBarFillEl.style.background = 'linear-gradient(90deg, #f59e0b, #fbbf24)';
    } else {
      healthBarFillEl.style.background = 'linear-gradient(90deg, #ef4444, #f87171)';
    }
  }
  if (healthStatusEl) {
    if (healthScore > 70) {
      healthStatusEl.textContent = 'Network Health: Optimal';
      healthStatusEl.className = 'badge badge-stable';
    } else if (healthScore > 40) {
      healthStatusEl.textContent = 'Network Health: Moderate Degradation';
      healthStatusEl.className = 'badge badge-warning';
    } else {
      healthStatusEl.textContent = 'Network Health: Critical Failure Risk';
      healthStatusEl.className = 'badge badge-danger';
    }
  }

  if (pulseEl) {
    pulseEl.className = `pulse-indicator ${evaluation.pulseClass}`;
  }
}

/**
 * Global Settings Modal Controller
 */
function setupSettingsModal() {
  const modal = document.getElementById('settings-modal');
  if (!modal) return;

  const openTriggers = document.querySelectorAll('[data-open-modal="settings-modal"], a[href="#settings-modal"]');
  const closeTriggers = modal.querySelectorAll('[data-close-modal], .modal-backdrop, .modal-close-btn');

  openTriggers.forEach((trigger) => {
    trigger.addEventListener('click', (e) => {
      e.preventDefault();
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    });
  });

  closeTriggers.forEach((btn) => {
    btn.addEventListener('click', () => {
      modal.classList.remove('active');
      document.body.style.overflow = '';
    });
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('active')) {
      modal.classList.remove('active');
      document.body.style.overflow = '';
    }
  });

  // Settings clear cache button
  const clearCacheBtn = document.getElementById('btn-clear-cache');
  if (clearCacheBtn) {
    clearCacheBtn.addEventListener('click', () => {
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem('linkpulse_recovery_history');
      alert('LinkPulse local storage and cached telemetry reset to baseline.');
      window.location.reload();
    });
  }
}

// Auto-run on DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
  setupMobileNavigation();
  setupSettingsModal();
  // Check if we are on the Home page by looking for dash-status
  if (document.getElementById('dash-status')) {
    initHomeDashboard();
  }
});
